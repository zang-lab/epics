#reset
rm(list=ls())
old.par <- par(mar = c(0, 0, 0, 0))
par(old.par)

library(xtable) #for table creation for latex
library(clue)#for predicting kmeans
library(matrixStats)#for rowQuantiles


#loading custom functions
source('r_functions.r')

#reporting session info
sessionInfo()
#set seed for reproducability
set.seed(178019)

#metrics for evaluation
mets<-matrix(nrow=2, ncol=3, data=0)
colnames(mets)<-c("JI", "Acc.", "Balanced Acc.")
rownames(mets)<-c("Rep 1", "Rep 2")

#shape metrics
cd_1 = read.table('CDS_SHAPES_rep1.txt', sep=',', header=TRUE)
cd_2 = read.table('CDS_SHAPES_rep1_part2.txt', sep=',', header=TRUE)
cd_3 = read.table('CDS_SHAPES_rep2.txt', sep=',', header=TRUE)
cd_4 = read.table('CDS_SHAPES_rep2_part2.txt', sep=',', header=TRUE)

data = rbind(cd_1, cd_2, cd_3, cd_4)
Ecc_13<-data$E1/data$E3
Ecc_23<-data$E2/data$E3
data<-cbind(data, Ecc_13, Ecc_23)

#shape metrics
in_1 = read.table('CDS_INTENSITY_rep1.txt', sep=',', header=TRUE)
in_2 = read.table('CDS_INTENSITY_rep1_part2.txt', sep=',', header=TRUE)
in_3 = read.table('CDS_INTENSITY_rep2.txt', sep=',', header=TRUE)
in_4 = read.table('CDS_INTENSITY_rep2_part2.txt', sep=',', header=TRUE)

in_data = rbind(in_1, in_2, in_3, in_4)
data<-cbind(data, in_data)


#creating replication factor
reps<-c(rep(1, (dim(in_1)[1]+dim(in_2)[1] ) ),
        rep(2, (dim(in_3)[1]+dim(in_4)[1] ) ))
temp<-as.data.frame(cbind(data, reps))
temp2<-temp[which(reps==1),]
temp2<-temp2[,-dim(temp2)[2]]

###############
#rep 1
###############
#k-means clustering from
#https://www.statmethods.net/advstats/cluster.html
mydata <- scale(temp[which(reps==1),-c(6, 10, 11, 12, 24)] ) # standardize variables
#remove reps
mydata<-mydata[,-dim(mydata)[2]]
#assume open and closed (2 clusters)
fit <- kmeans(mydata, 2)

rep1_cols = as.numeric(fit$cluster)
table(rep1_cols)

vals_ones<-which(rep1_cols==1)
vals_twos<-which(rep1_cols==2)

m1<-mean(temp2$Mean[vals_ones])
m2<-mean(temp2$Mean[vals_twos])

m1
m2

if(m1>m2){

  rep1_cols[which(rep1_cols==1)]=1 #closed = blue = 1
  rep1_cols[which(rep1_cols==2)]=0#green = open = 0

}else{
    rep1_cols[which(rep1_cols==1)]=0#green = open = 0
  rep1_cols[which(rep1_cols==2)]=1 #closed = blue = 1


}


##########################
#bootstrap Jaccard Index
##########################

#number of times performing bootstrap
num_times=100
#object to hold all jaccard indexes
ji<-matrix(nrow=num_times, ncol=1, data=0)
#accuracy
acc<-matrix(nrow=num_times, ncol=1, data=0)
#balanced accuracy
b_acc<-matrix(nrow=num_times, ncol=1, data=0)
#number of samples to take
num_samps<-250

for (i in 1:num_times) {
    #selecting new bootstrap sample
    new_samp_vals=sample(x=1:dim(mydata)[1], size=num_samps, replace=TRUE)
    new_samp = mydata[new_samp_vals,]
    #forming clusters via k-means
    new_fit <- kmeans(new_samp, 2)
    #predicting classes on original data
    new_pred<-cl_predict(new_fit, mydata)
    #assigning cluster appropriately using automation
    rep1_new = as.numeric(new_pred)
    vals_ones<-which(rep1_new==1)
    vals_twos<-which(rep1_new==2)
    m1<-mean(temp2$Mean[vals_ones])
    m2<-mean(temp2$Mean[vals_twos])
    if(m1>m2){

      rep1_new[which(rep1_new==1)]=1 #closed = blue = 1
      rep1_new[which(rep1_new==2)]=0#green = open = 0

    }else{
        rep1_new[which(rep1_new==1)]=0#green = open = 0
      rep1_new[which(rep1_new==2)]=1 #closed = blue = 1


    }

    ji[i,1]<-jaccard(rep1_new, rep1_cols)
    acc[i,1]<-mean(rep1_new==rep1_cols)
    b_acc[i,1]<-bal_acc(rep1_new,rep1_cols)
}

mets[1,1]<-mean(ji)
sd(ji)
mets[1,2]<-mean(acc)
mets[1,3]<-mean(b_acc)

###############
#rep 2
###############
#k-means clustering from
#https://www.statmethods.net/advstats/cluster.html
mydata <- scale(temp[which(reps==2),-c(6, 10, 11, 12, 24)] ) # standardize variables
#remove reps
mydata<-mydata[,-dim(mydata)[2]]
#assume open and closed (2 clusters)
fit <- kmeans(mydata, 2)

rep1_cols = as.numeric(fit$cluster)
table(rep1_cols)

vals_ones<-which(rep1_cols==1)
vals_twos<-which(rep1_cols==2)

m1<-mean(temp2$Mean[vals_ones])
m2<-mean(temp2$Mean[vals_twos])

m1
m2

if(m1>m2){

  rep1_cols[which(rep1_cols==1)]=1 #closed = blue = 1
  rep1_cols[which(rep1_cols==2)]=0#green = open = 0

}else{
    rep1_cols[which(rep1_cols==1)]=0#green = open = 0
  rep1_cols[which(rep1_cols==2)]=1 #closed = blue = 1


}


##########################
#bootstrap Jaccard Index
##########################

#number of times performing bootstrap
num_times=100
#object to hold all jaccard indexes
ji<-matrix(nrow=num_times, ncol=1, data=0)
#accuracy
acc<-matrix(nrow=num_times, ncol=1, data=0)
#balanced accuracy
b_acc<-matrix(nrow=num_times, ncol=1, data=0)
#number of samples to take
num_samps<-250

for (i in 1:num_times) {
    #selecting new bootstrap sample
    new_samp_vals=sample(x=1:dim(mydata)[1], size=num_samps, replace=TRUE)
    new_samp = mydata[new_samp_vals,]
    #forming clusters via k-means
    new_fit <- kmeans(new_samp, 2)
    #predicting classes on original data
    new_pred<-cl_predict(new_fit, mydata)
    #assigning cluster appropriately using automation
    rep1_new = as.numeric(new_pred)
    vals_ones<-which(rep1_new==1)
    vals_twos<-which(rep1_new==2)
    m1<-mean(temp2$Mean[vals_ones])
    m2<-mean(temp2$Mean[vals_twos])
    if(m1>m2){

      rep1_new[which(rep1_new==1)]=1 #closed = blue = 1
      rep1_new[which(rep1_new==2)]=0#green = open = 0

    }else{
        rep1_new[which(rep1_new==1)]=0#green = open = 0
      rep1_new[which(rep1_new==2)]=1 #closed = blue = 1


    }

    ji[i,1]<-jaccard(rep1_new, rep1_cols)
    acc[i,1]<-mean(rep1_new==rep1_cols)
    b_acc[i,1]<-bal_acc(rep1_new,rep1_cols)
}

mets[2,1]<-mean(ji)
sd(ji)
mets[2,2]<-mean(acc)
mets[2,3]<-mean(b_acc)

#display results
mets

xtable(mets)

#
