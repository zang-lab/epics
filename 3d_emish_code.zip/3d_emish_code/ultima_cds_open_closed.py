#collects shape and intensity metrics from 3D EMISH data to report shape metrics on each CD
import md_tif as md


############
# batch 1
############

#7x7x50

dist1 = ["replicate I", "none"]

#name of .txt file
name = 'rep1.txt'
name2 = 'rep1'
val = 7

#converting images
md.BinaryCDsTXT(name2, dist1, val)

dist1 = ["replicate I part2", "none"]

#name of .txt file
name = 'rep1_part2.txt'
name2 = 'rep1_part2'
val = 7

#converting images
md.BinaryCDsTXT(name2, dist1, val)

############
#batch 2
############

#5x5x30

dist2 = ["replicate II", "none"]

#name of .txt file
name = 'rep2.txt'
name2 = 'rep2'
val = 3

#converting images
md.BinaryCDsTXT(name2, dist2, val)

dist2 = ["replicate II part2", "none"]

#name of .txt file
name = 'rep2_part2.txt'
name2 = 'rep2_part2'
val = 3

#converting images
md.BinaryCDsTXT(name2, dist2, val)
