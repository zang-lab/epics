#reset
rm(list=ls())
old.par <- par(mar = c(0, 0, 0, 0))
par(old.par)

library(xtable) #for table creation for latex
library(caret)#for more info on training rf
library(glmnet)
library(clue)#for predicting kmeans
library(scatterplot3d)#for 3d plot in r
library(Hmisc)#for minor ticks
library(pROC)#for ROC curves
library(ggplot2)#for scatterplot matrix with other plots
library(GGally)#for scatterplot matrix with other plots

#loading custom functions
source('r_functions.r')

#reporting session info
sessionInfo()
#set seed for reproducability
set.seed(178019)

#size check metrics
size_1 = read.table('IMAGE_SIZESrep1.txt', sep=',', header=TRUE)
size_2 = read.table('IMAGE_SIZESrep1_part2.txt', sep=',', header=TRUE)
size_3 = read.table('IMAGE_SIZESrep2.txt', sep=',', header=TRUE)
size_4 = read.table('IMAGE_SIZESrep2_part2.txt', sep=',', header=TRUE)

data = rbind(size_1, size_2, size_3, size_4)

total = sum(data[,1]*data[,2]*data[,3])

total
(total- (499*6))/total


#shape metrics
cd_1 = read.table('CDS_SHAPES_rep1.txt', sep=',', header=TRUE)
cd_2 = read.table('CDS_SHAPES_rep1_part2.txt', sep=',', header=TRUE)
cd_3 = read.table('CDS_SHAPES_rep2.txt', sep=',', header=TRUE)
cd_4 = read.table('CDS_SHAPES_rep2_part2.txt', sep=',', header=TRUE)

data = rbind(cd_1, cd_2, cd_3, cd_4)
Ecc_13<-data$E1/data$E3
Ecc_23<-data$E2/data$E3
data<-cbind(data, Ecc_13, Ecc_23)

#shape metrics
in_1 = read.table('CDS_INTENSITY_rep1.txt', sep=',', header=TRUE)
in_2 = read.table('CDS_INTENSITY_rep1_part2.txt', sep=',', header=TRUE)
in_3 = read.table('CDS_INTENSITY_rep2.txt', sep=',', header=TRUE)
in_4 = read.table('CDS_INTENSITY_rep2_part2.txt', sep=',', header=TRUE)

in_data = rbind(in_1, in_2, in_3, in_4)
data<-cbind(data, in_data)


#creating replication factor
reps<-c(rep(1, (dim(in_1)[1]+dim(in_2)[1] ) ),
        rep(2, (dim(in_3)[1]+dim(in_4)[1] ) ))

#counts plot
temp<-as.data.frame(cbind(data, reps))
png("reps.png", width = 4000, height = 4000)
  plot(temp, col=temp$reps)
dev.off()

png("only_rep1.png", width = 4000, height = 4000)
  plot(temp[which(reps==1),])
dev.off()

png("only_rep2.png", width = 4000, height = 4000)
  plot(temp[which(reps==1),], col='red')
dev.off()


#############
## Rep 1
#############

#k-means clustering from
#https://www.statmethods.net/advstats/cluster.html
mydata <- scale(temp[which(reps==1),-c(6, 10, 11, 12, 24)] ) # standardize variables
#assume open and closed (2 clusters)
fit <- kmeans(mydata, 2)

rep1_cols = as.character(fit$cluster)
table(rep1_cols)
rep1_cols[which(rep1_cols=='1')]='green' #green = open = 0
rep1_cols[which(rep1_cols=='2')]='blue'  #closed = blue = 1

png("only_rep1.png", width = 4000, height = 4000)
  plot(temp[which(reps==1),-c(6, 10, 11, 12, 24)], col=rep1_cols)
dev.off()

#setup for model
train<-as.data.frame(cbind(as.factor(fit$cluster),
                          temp[which(reps==1),-c(6, 10, 11, 12, 24)] ))
colnames(train)[1]<-"labs_df"

keep1<-which(train$labs_df==1)
keep2<-which(train$labs_df==2)

#70% for training and 30% for validation
obs_1 = sample(keep1, floor(length(keep1)*0.70), replace=FALSE)
obs_2 = sample(keep2, floor(length(keep2)*0.70), replace=FALSE)

obs<-c(obs_1, obs_2)

x<-as.matrix(train[obs,-1])
y<-as.matrix(train[obs,1])
y[which(y==1)]=0
y[which(y==2)]=1
y<-as.matrix(as.numeric(y))

#perform cv to obtain less variables
tune.out<-cv.glmnet(x,y,family="binomial",type.measure="class", nfolds=10)

#print results
plot(tune.out)
tune.out$lambda.min
vars_keep<-as.matrix(coef(tune.out, s=tune.out$lambda.min))
xtable(vars_keep, digits=4)

png("only_rep1_lasso.png", width = 1000, height = 1000)
  plot(train[which(vars_keep!=0)[-1]], col=rep1_cols)
dev.off()

glm_df<-cbind(y, train[obs,which(vars_keep!=0)[-1]])

#build model with non-zero variable
lr_ultima<-glm(y~.,
              data=glm_df,
              family=binomial(),
              control = list(maxit = 50))

#variable importance
varImp(lr_ultima)

#output accuracy on training data
ypred=(predict(lr_ultima,glm_df, type='response')>0.5)+0.0
table(predict=ypred, truth=y)
mean(ypred==y)

#confusion matrix
confusionMatrix(as.factor(ypred), as.factor(y))

#collecting accuracy on validation data
y<-as.matrix(train[-obs,1])
y[which(y==1)]=0
y[which(y==2)]=1
glm_df<-cbind(y, train[-obs,which(vars_keep!=0)[-1]])

ypred=(predict(lr_ultima,glm_df, type='response')>0.5)+0.0
table(predict=ypred, truth=y)
mean(ypred==y)

#confusion matrix for validation data
confusionMatrix(as.factor(ypred), as.factor(y))

#############
## Rep 2
#############

#k-means clustering from
#https://www.statmethods.net/advstats/cluster.html
mydata <- scale(temp[which(reps==2),-c(6, 10, 11, 12, 24)]) # standardize variables
#assume open and closed (2 clusters)
fit <- kmeans(mydata, 2)


rep2_cols = as.character(fit$cluster)
table(rep2_cols)
rep2_cols[which(rep2_cols=='1')]='green'#green = open = 0
rep2_cols[which(rep2_cols=='2')]='blue' #blue = close = 1

png("only_rep2.png", width = 4000, height = 4000)
  plot(temp[which(reps==2),-c(6, 10, 11, 12, 24)], col=rep2_cols)
dev.off()

#setup for model
train<-as.data.frame(cbind(as.factor(fit$cluster), temp[which(reps==2),-c(6, 10, 11, 12, 24)]))
colnames(train)[1]<-"labs_df"

keep1<-which(train$labs_df==1)
keep2<-which(train$labs_df==2)

#70% for training and 30% for validation
obs_1 = sample(keep1, floor(length(keep1)*0.70), replace=FALSE)
obs_2 = sample(keep2, floor(length(keep2)*0.70), replace=FALSE)

obs<-c(obs_1, obs_2)

x<-as.matrix(train[obs,-1])
y<-as.matrix(train[obs,1])
y[which(y==1)]=0
y[which(y==2)]=1
y<-as.matrix(as.numeric(y))

#perform cv to obtain less variables
tune.out<-cv.glmnet(x,y,family="binomial",type.measure="class", nfolds=10)

#print results
plot(tune.out)
tune.out$lambda.min
vars_keep<-as.matrix(coef(tune.out, s=tune.out$lambda.min))
xtable(vars_keep, digits=4)

png("only_rep2_lasso.png", width = 1000, height = 1000)
  plot(train[which(vars_keep!=0)[-1]], col=rep2_cols)
dev.off()

glm_df<-cbind(y, train[obs,which(vars_keep!=0)[-1]])

#build model with non-zero variable
lr_ultima<-glm(y~.,
              data=glm_df,
              family=binomial(),
              control = list(maxit = 50))

#variable importance
varImp(lr_ultima)

#output accuracy on training data
ypred=(predict(lr_ultima,glm_df, type='response')>0.5)+0.0
table(predict=ypred, truth=y)
mean(ypred==y)

#confusion matrix
confusionMatrix(as.factor(ypred), as.factor(y))

#collecting accuracy on validation data
y<-as.matrix(train[-obs,1])
y[which(y==1)]=0
y[which(y==2)]=1
glm_df<-cbind(y, train[-obs,which(vars_keep!=0)[-1]])

ypred=(predict(lr_ultima,glm_df, type='response')>0.5)+0.0
table(predict=ypred, truth=y)
mean(ypred==y)

#confusion matrix for validation data
confusionMatrix(as.factor(ypred), as.factor(y))


####################
## Rep1 and Rep2
####################

######################
## Comparing Clusters
#####################

sep_cols<-c(rep1_cols, rep2_cols)


######################################
#redoing analysis but with each separate k-means clustering
# i.e. using sep_cols as the clusters

png("sep_all_vars.png", width = 4000, height = 4000)
  plot(temp, col=sep_cols)
dev.off()

#setup for model
train<-as.data.frame(cbind(as.factor(sep_cols), temp[,-c(6, 10, 11, 12, 24)]))
colnames(train)[1]<-"labs_df"

keep1<-which(train$labs_df=='blue')
keep2<-which(train$labs_df=='green')

#70% for training and 30% for validation
obs_1 = sample(keep1, floor(length(keep1)*0.70), replace=FALSE)
obs_2 = sample(keep2, floor(length(keep2)*0.70), replace=FALSE)

obs<-c(obs_1, obs_2)

x<-as.matrix(train[obs,-1])
y<-as.matrix(train[obs,1])
y[which(y=='green')]=0
y[which(y=='blue')]=1
y<-as.matrix(as.numeric(y))

#build model using LASSO
train<-as.data.frame(cbind(as.factor(sep_cols), temp[,-c(6, 10, 11, 12, 24)]))

#perform cv to obtain less variables
tune.out<-cv.glmnet(x,y,family="binomial",type.measure="class", nfolds=10)

#print results
plot(tune.out)
tune.out$lambda.min
tune.out$lambda.1se
vars_keep<-as.matrix(coef(tune.out, s=tune.out$lambda.1se))
xtable(vars_keep, digits=4)

png("sep_lasso.png", width = 1000, height = 1000)
  plot(train[which(vars_keep!=0)[-1]], col=sep_cols)
dev.off()


shapes = c(16, 2)
shapes <- shapes[as.numeric(train[,1])]

png("sep_lasso_rep1.png", width = 1000, height = 1000)
  #par(oma=c(20, 5, 20, 20))
  pairs(train[which(vars_keep!=0)[-1]][which(reps==1),],
        col=sep_cols[which(reps==1)],
        pch=shapes[which(reps==1)],
        lower.panel=NULL,
        cex.axis=2.5,
        cex.labels=4,
        las=2,
        oma=c(7, 5, 7, 7)
      )
  par(xpd=TRUE)
  legend('bottomleft',
        legend = levels(as.factor(c("Open", "Closed"))),
        col =  c("blue", "green"),
        pch = c(16, 2),
        cex=3
      )
dev.off()

png("sep_lasso_rep2.png", width = 1000, height = 1000)
  plot(train[which(vars_keep!=0)[-1]][which(reps==2),],
        col=sep_cols[which(reps==2)],
        pch=shapes[which(reps==2)],
        lower.panel=NULL,
        cex.axis=2.5,
        cex.labels=4,
        las=2,
        oma=c(7, 5, 7, 7)
      )
  par(xpd=TRUE)
  legend('bottomleft',
        legend = levels(as.factor(c("Open", "Closed"))),
        col =  c("blue", "green"),
        pch = c(16, 2),
        cex=3
      )
dev.off()


glm_df<-cbind(y, train[obs,which(vars_keep!=0)[-1]])

#build model with non-zero variable
lr_ultima<-glm(y~.,
              data=glm_df,
              family=binomial(),
              control = list(maxit = 50))

#variable importance
varImp(lr_ultima)

#output accuracy on training data
ypred=(predict(lr_ultima,glm_df, type='response')>0.5)+0.0
table(predict=ypred, truth=y)
mean(ypred==y)

#confusion matrix
confusionMatrix(as.factor(ypred), as.factor(y))

#collecting accuracy on validation data
y<-as.matrix(train[-obs,1])
y[which(y=='green')]=0
y[which(y=='blue')]=1
y<-as.matrix(as.numeric(y))

glm_df<-cbind(y, train[-obs,which(vars_keep!=0)[-1]])

ypred=(predict(lr_ultima,glm_df, type='response')>0.5)+0.0
table(predict=ypred, truth=y)
mean(ypred==y)

#confusion matrix for validation data
confusionMatrix(as.factor(ypred), as.factor(y))

##########
#lasso model using lambda with 1 s.e.
vars_keep<-as.matrix(coef(tune.out, s=tune.out$lambda.1se))
xtable(vars_keep, digits=4)

shapes = c(16, 2)
shapes <- shapes[as.numeric(train[,1])]

png("sep_lasso_1se.png", width = 1000, height = 1000)
plot(train[which(vars_keep!=0)[-1]],
     col=sep_cols,
     pch=shapes,
     lower.panel=NULL
   )
par(xpd=TRUE)
legend('bottomleft',
      legend = levels(as.factor(c("Open", "Closed"))),
      col =  c("blue", "green"),
      pch = c(16, 2),
      cex=3
    )
dev.off()

my_df<-train[c(1,which(vars_keep!=0)[-1])]
colnames(my_df)[1]<-"CD"
my_df[,1]<-as.character(my_df[,1])

my_df[which(my_df[,1]=='green'),1]='Open'
my_df[which(my_df[,1]=='blue'),1]='Closed'
my_df[,1]<-as.factor(my_df[,1])

my_colors <- c("Closed" = "blue", "Open" = "green")
my_shapes<-c("Closed" = 16, "Open" = 2)

pm<-ggpairs(my_df,
        mapping = aes(color = CD, shape=CD),
        upper=list(continuous=wrap('points', alpha=0.7, size=3)),
        lower=list(continuous=wrap('density')),
        diag = list(continuous = wrap("densityDiag", alpha=0.5),
                    discrete = "barDiag",
                    na = "naDiag"),
        legend=1,
      ) +
  scale_color_manual(values = my_colors)+
  scale_fill_manual(values = my_colors)+
  scale_shape_manual(values= my_shapes)+
  theme(legend.position = 'left',
        text = element_text(size=30),
        axis.text.x = element_text(angle = 270)
      )
#
#pm[6,1] = pm[6,1]+scale_y_continuous(guide = guide_axis(n.dodge = 2))
pm[6,1] = pm[6,1]+scale_y_continuous(breaks=c(0, 20, 40))
png("sep_lasso_1se_more.png", width = 1500, height = 1500)
pm
dev.off()



#Spherecity
png("Spherecity_hist.png", width = 500, height = 500)
hist_2(data=train[which(vars_keep!=0)[-1]][,1],
       classes=which(train[,1]),
       var.name=colnames(train[which(vars_keep!=0)[-1]])[1]
      )
dev.off()

#E1
png("E1_hist.png", width = 500, height = 500)
hist_2(data=train[which(vars_keep!=0)[-1]][,2],
       classes=which(train[,1]),
       var.name=colnames(train[which(vars_keep!=0)[-1]])[2]
      )
dev.off()

#E3
png("E3_hist.png", width = 500, height = 500)
hist_2(data=train[which(vars_keep!=0)[-1]][,3],
       classes=which(train[,1]),
       var.name=colnames(train[which(vars_keep!=0)[-1]])[3]
      )
dev.off()

#Q3
png("Q3_hist.png", width = 500, height = 500)
hist_2(data=train[which(vars_keep!=0)[-1]][,4],
       classes=which(train[,1]),
       var.name=colnames(train[which(vars_keep!=0)[-1]])[4]
      )
dev.off()

#Max
png("Max_hist.png", width = 500, height = 500)
hist_2(data=train[which(vars_keep!=0)[-1]][,5],
       classes=which(train[,1]),
       var.name=colnames(train[which(vars_keep!=0)[-1]])[5]
      )
dev.off()


png("batch_effects.png", width = 1000, height = 1000)
  plot(train[which(vars_keep!=0)[-1]],
       col=reps,
       lower.panel=NULL,,
       cex.axis=2.5,
       cex.labels=4,
       las=2,
       oma=c(7, 5, 7, 7)
     )
  par(xpd=TRUE)
  legend('bottomleft',
        legend = levels(as.factor(c("Batch 1", "Batch 2"))),
        col = c('black', 'red'),
        pch=1,
        cex=3
      )
dev.off()

x<-as.matrix(train[obs,-1])
y<-as.matrix(train[obs,1])
y[which(y=='green')]=0
y[which(y=='blue')]=1
y<-as.matrix(as.numeric(y))

glm_df<-cbind(y, train[obs,which(vars_keep!=0)[-1]])

#build model with non-zero variable
lr_ultima<-glm(y~.,
              data=glm_df,
              family=binomial(),
              control = list(maxit = 50))

#summary of model
summary(lr_ultima)

#displaying coefficient values
xtable(as.matrix(summary(lr_ultima)[['coefficients']][,'Estimate']),
      digits=4)

#variable importance
vi<-varImp(lr_ultima)
vi

ts<-abs(summary(lr_ultima)[['coefficients']][,'z value'])
#removing intercept
t_final<-ts[-1]

#sorting by importance
sort(t_final, decreasing=TRUE)

#usually provided relative to the max
sort(t_final, decreasing=TRUE)/max(t_final)

xtable((as.matrix(sort(t_final, decreasing=TRUE)/max(t_final))) ,
       digits=4)

#as plot

VI<-sort(t_final, decreasing=TRUE)/max(t_final)
vi_names<-names(VI)
#vi_names[5]<-'White EI'
#vi_names[6]<-'Surface Area'

png("vi_plot.png", width = 1000, height = 1000)
    par(col.axis="black", cex.axis=3, mar=c(12, 12, 5, 5))
    plot(VI, xlab=' ', ylab=" " , xaxt='n', ann=FALSE, type='n' )
    title(main='VI for 3D-EMISH',
          cex.main=4)
    #title(xlab='Variable',
    #      cex.lab=3.5,
    #      line=8)
    title(ylab="Relative Variable Importance",
          cex.lab=3.5,
          line=5)
    lines(x=1, VI[1],type='h', col=rgb(128, 0, 0, maxColorValue=255), lwd=100, lend='square')
    lines(x=2, VI[2],type='h', col=rgb(255, 255, 0, maxColorValue=255), lwd=100, lend='square')
    lines(x=3, VI[3],type='h', col=rgb(112, 15, 112, maxColorValue=255), lwd=100, lend='square')
    lines(x=4, VI[4],type='h', col=rgb(255, 179, 217, maxColorValue=255), lwd=100, lend='square')
    lines(x=5, VI[5],type='h', col=rgb(255, 165, 0, maxColorValue=255), lwd=100, lend='square')
    #lines(VI,type='h', col='cyan', lwd=15)
    #lines(VI,type='h', col='blue', lwd=10)
    axis(side=1, labels=FALSE)
    text(par("usr")[3],
         x=1:6,
         labels = vi_names,
         pos=1,
         xpd=TRUE,
         cex=3)
dev.off()

png("vi_plot.png", width = 1000, height = 1000)
    par(col.axis="black", cex.axis=3, mar=c(12, 12, 5, 5))
    barplot(VI, xlab=' ', ylab=" " , #xaxt='n', ann=FALSE,# type='n',
            col=c(rgb(128, 0, 0, maxColorValue=255),
                  rgb(255, 255, 0, maxColorValue=255),
                  rgb(112, 15, 112, maxColorValue=255),
                  rgb(255, 179, 217, maxColorValue=255),
                  rgb(255, 165, 0, maxColorValue=255)
                  )
           )
    title(main='VI for 3D-EMISH',
          cex.main=4)
    title(ylab="Relative Variable Importance",
          cex.lab=3.5,
          line=5)
dev.off()

colors <- sep_cols
shapes = c(16, 2)
shapes <- shapes[as.numeric(train[,1])]

png("3d_scat.png", width = 400, height = 400)
    s3d<-scatterplot3d(train$Q3, train$Max, train$Sphericity,
                  main="3D Scatterplot of 3D-EMISH CDs",
                  xlab="Q3",
                  ylab="Max",
                  zlab="Spherecity",
                  pch=shapes,
                  color=colors,
                  #angle=120)
                  angle=110)
    legend(s3d$xyz.convert(20000, 65000, 2), legend = levels(as.factor(c("Open", "Closed"))),
          col =  c("blue", "green"), pch = c(16, 2))
dev.off()


#histograms for explaining top 5 variables
#Q3
A<-(train$Q3[which(train[,1]=='blue')])
B<-(train$Q3[which(train[,1]=='green')])

b<-min(c(A, B))-max(c(sd(A), sd(B)))
e<-max(c(A, B))+max(c(sd(A), sd(B)))
ax <- pretty(b:e, n = 15) # Make a neat vector for the breakpoints
ax

hgA <- hist(A, breaks = ax, plot = FALSE) # Save first histogram data
hgB <- hist(B, breaks = ax, plot = FALSE) # Save 2nd histogram data

frq<-max(c(hgA$counts, hgB$counts))

c1=rgb(0,0,255,max = 255, alpha = 95, names = "lt.blue")
c2=rgb(0,255,0,max = 255, alpha = 95, names = "lt.green")
axis_x<-as.character(ax)
axis_x[1]<-"More"
axis_x[length(axis_x)-1]<-""
axis_x[length(axis_x)]<-"Less"

png("Q3_hist.png", width = 700, height = 500)
plot(hgA, col = c1, ylim=c(0,frq),
     main="Histogram of Q3",
     xlab="Third Quantile of Density of Genetic Material",
     xaxt='n',
    cex.main=3,
    cex.lab=1.3)
plot(hgB, col = c2,
     add = TRUE,
     ylim=c(0,frq),
     xaxt='n') # Add 2nd histogram using different color
axis(1, at=ax, labels=axis_x)
dev.off()

png("Q3_hist_both.png", width = 1400, height = 600, res=100)
par(mar=c(10,6,5,0)+0.01)
hist(c(A, B), col = rgb(128, 0, 0, maxColorValue=255),
     main="Histogram of Q3",
     xlab=" ",
    cex.main=5,
    cex.lab=4,
    cex.axis=3,
    breaks=60
    )
    mtext(side=1, line=5, "Q3 of Density of Genetic Material",cex=4)
dev.off()

#Sphericity
A<-(train$Sphericity[which(train[,1]=='blue')])
B<-(train$Sphericity[which(train[,1]=='green')])

b<-min(c(A, B))-max(c(sd(A), sd(B)))
e<-max(c(A, B))+max(c(sd(A), sd(B)))
ax <- pretty(b:e, n = 15) # Make a neat vector for the breakpoints
ax

hgA <- hist(A, breaks = ax, plot = FALSE) # Save first histogram data
hgB <- hist(B, breaks = ax, plot = FALSE) # Save 2nd histogram data

frq<-max(c(hgA$counts, hgB$counts))

c1=rgb(0,0,255,max = 255, alpha = 95, names = "lt.blue")
c2=rgb(0,255,0,max = 255, alpha = 95, names = "lt.green")
axis_x<-as.character(ax)
axis_x[10]<-""
axis_x[12]<-""
axis_x[11]<-"More"
axis_x[length(axis_x)-1]<-""
axis_x[length(axis_x)]<-"Less"
axis_x[1]<-"Less"
axis_x[2]<-""


png("Sphericity_hist.png", width = 700, height = 500)
plot(hgA, col = c1, ylim=c(0,frq),
     main="Histogram of Sphericity",
     xlab="Sphericity of Genetic Material",
     xaxt='n',
    cex.main=3,
    cex.lab=1.3)
plot(hgB, col = c2,
     add = TRUE,
     ylim=c(0,frq),
     xaxt='n') # Add 2nd histogram using different color
axis(1, at=ax, labels=axis_x)
dev.off()

png("Sphericity_hist_both.png", width = 1400, height = 600, res=100)
par(mar=c(10,6,5,0)+0.01)
hist(c(A, B), col = rgb(112, 15, 112, maxColorValue=255),
     main="Histogram of Spherecity",
     xlab=" ",
    cex.main=5,
    cex.lab=4,
    cex.axis=3,
    breaks=60
  )
    mtext(side=1, line=5, "Sphericity of Genetic Material",cex=4)
dev.off()

#Max
A<-(train$Max[which(train[,1]=='blue')])
B<-(train$Max[which(train[,1]=='green')])

b<-min(c(A, B))-max(c(sd(A), sd(B)))
e<-max(c(A, B))+max(c(sd(A), sd(B)))
ax <- pretty(b:e, n = 15) # Make a neat vector for the breakpoints
ax

hgA <- hist(A, breaks = ax, plot = FALSE) # Save first histogram data
hgB <- hist(B, breaks = ax, plot = FALSE) # Save 2nd histogram data

frq<-max(c(hgA$counts, hgB$counts))

c1=rgb(0,0,255,max = 255, alpha = 95, names = "lt.blue")
c2=rgb(0,255,0,max = 255, alpha = 95, names = "lt.green")
axis_x<-as.character(ax)
axis_x[1]<-"More"
axis_x[length(axis_x)-1]<-""
axis_x[length(axis_x)]<-"Less"

png("Max_hist.png", width = 700, height = 500)
plot(hgA, col = c1, ylim=c(0,frq),
     main="Histogram of Max",
     xlab="Maximum of Genetic Material",
     xaxt='n',
    cex.main=3,
    cex.lab=1.3)
plot(hgB, col = c2,
     add = TRUE,
     ylim=c(0,frq),
     xaxt='n') # Add 2nd histogram using different color
axis(1, at=ax, labels=axis_x)
dev.off()

png("Max_hist_both.png", width = 1400, height = 600, res=100)
par(mar=c(10,6,5,0)+0.01)
hist(c(A, B), col = rgb(255, 255, 0, maxColorValue=255),
     main="Histogram of Max",
     xlab=" ",
    cex.main=5,
    cex.lab=4,
    cex.axis=3,
    breaks=60,
     xaxt='n') # Add 2nd histogram using different color
axis(1, at=c(30000, 40000, 50000, 60000), labels=c(30000, 40000, 50000, 60000), cex.axis=3)
mtext(side=1, line=5, "Max of Density of Genetic Material",cex=4)
dev.off()


#E1
A<-(train$E1[which(train[,1]=='blue')])
B<-(train$E1[which(train[,1]=='green')])

b<-min(c(A, B))-max(c(sd(A), sd(B)))
e<-max(c(A, B))+max(c(sd(A), sd(B)))
ax <- pretty(b:e, n = 15) # Make a neat vector for the breakpoints
ax

hgA <- hist(A, breaks = ax, plot = FALSE) # Save first histogram data
hgB <- hist(B, breaks = ax, plot = FALSE) # Save 2nd histogram data

frq<-max(c(hgA$counts, hgB$counts))

c1=rgb(0,0,255,max = 255, alpha = 95, names = "lt.blue")
c2=rgb(0,255,0,max = 255, alpha = 95, names = "lt.green")
axis_x<-as.character(ax)
axis_x[1]<-"Smaller"
axis_x[length(axis_x)-1]<-""
axis_x[length(axis_x)]<-"Larger"

png("E1_hist.png", width = 700, height = 500)
plot(hgA, col = c1, ylim=c(0,frq),
     main="Histogram of E1",
     xlab="Major Axis Length of Genetic Material",
     xaxt='n',
    cex.main=3,
    cex.lab=1.3)
plot(hgB, col = c2,
     add = TRUE,
     ylim=c(0,frq),
     xaxt='n') # Add 2nd histogram using different color
axis(1, at=ax, labels=axis_x)
dev.off()

png("E1_hist_both.png", width = 1400, height = 600, res=100)
par(mar=c(10,6,5,0)+0.01)
hist(c(A, B), col = rgb(255, 165, 0, maxColorValue=255),
     main="Histogram of E1",
     xlab=" ",
    cex.main=5,
    cex.lab=4,
    cex.axis=3,
     xaxt='n',
     breaks=60
   )
axis(1, at=c(0, 1000, 2000, 3000, 4000), labels=c(0, 1000, 2000, 3000, 4000 ), cex.axis=3)
mtext(side=1, line=5, "Major Axis Length of Genetic Material",cex=4)
dev.off()

#E3
A<-(train$W_EI[which(train[,1]=='blue')])
B<-(train$W_EI[which(train[,1]=='green')])

b<-min(c(A, B))-max(c(sd(A), sd(B)))
e<-max(c(A, B))+max(c(sd(A), sd(B)))
ax <- pretty(b:e, n = 15) # Make a neat vector for the breakpoints
ax

hgA <- hist(A, breaks = ax, plot = FALSE) # Save first histogram data
hgB <- hist(B, breaks = ax, plot = FALSE) # Save 2nd histogram data

frq<-max(c(hgA$counts, hgB$counts))

c1=rgb(0,0,255,max = 255, alpha = 95, names = "lt.blue")
c2=rgb(0,255,0,max = 255, alpha = 95, names = "lt.green")
axis_x<-as.character(ax)
axis_x[1]<-"Smaller"
axis_x[length(axis_x)-1]<-""
axis_x[length(axis_x)]<-"Larger"

png("E3_hist.png", width = 700, height = 500)
plot(hgA, col = c1, ylim=c(0,frq),
     main="Histogram of E3",
     xlab="Minor Axis Length of Genetic Material",
     xaxt='n',
    cex.main=3,
    cex.lab=1.3)
plot(hgB, col = c2,
     add = TRUE,
     ylim=c(0,frq),
     xaxt='n') # Add 2nd histogram using different color
axis(1, at=ax, labels=axis_x)
dev.off()

png("E3_hist_both.png", width = 1600, height = 600, res=100)
par(mar=c(10,6,5,0)+0.01)
hist(c(A, B), col = rgb(255, 179, 217, maxColorValue=255),
     main="Histogram of E3",
     xlab=" ",
    cex.main=5,
    cex.lab=4,
    cex.axis=3,
    breaks=60
  )
    mtext(side=1, line=5, "Minor Axis Length of Genetic Material",cex=4)
dev.off()


#output accuracy on training data
ypred=(predict(lr_ultima,glm_df, type='response')>0.5)+0.0
table(predict=ypred, truth=y)
mean(ypred==y)

xtable(table(predict=ypred, truth=y))

#confusion matrix
confusionMatrix(as.factor(ypred), as.factor(y))

#plot for training roc
png("roc_train.png", width = 500, height = 500)
      plot(roc(as.vector(y),
           as.vector(predict(lr_ultima,glm_df, type='response')),
           smooth=F),
           print.auc=TRUE,
          cex.lab=2,
          main="Training ROC",
          cex.main=2.5)
dev.off()


#collecting accuracy on validation data
y<-as.matrix(train[-obs,1])
y[which(y=='green')]=0
y[which(y=='blue')]=1
y<-as.matrix(as.numeric(y))

glm_df<-cbind(y, train[-obs,which(vars_keep!=0)[-1]])

ypred=(predict(lr_ultima,glm_df, type='response')>0.5)+0.0
table(predict=ypred, truth=y)
mean(ypred==y)

xtable(table(predict=ypred, truth=y))

#confusion matrix for validation data
confusionMatrix(as.factor(ypred), as.factor(y))


#plot for validaiton roc
png("roc_valid.png", width = 500, height = 500)
      plot(roc(as.vector(y),
           as.vector(predict(lr_ultima,glm_df, type='response')),
           smooth=F),
           print.auc=TRUE,
          cex.lab=2,
          main="Validation ROC",
          cex.main=2.5)
dev.off()


###########################
#Batch Effects Model
###########################

#model for classifying between batch effects


x<-as.matrix(train[obs,-1])
y<-as.matrix(reps[obs])
y[which(y==2)]=0
y<-as.matrix(as.numeric(y))

glm_df<-cbind(y, train[obs,which(vars_keep!=0)[-1]])

#build model with non-zero variable
lr_ultima<-glm(y~.,
              data=glm_df,
              family=binomial(),
              control = list(maxit = 50))

#summary of model
summary(lr_ultima)

#output accuracy on training data
ypred=(predict(lr_ultima,glm_df, type='response')>0.5)+0.0
table(predict=ypred, truth=y)
mean(ypred==y)

xtable(table(predict=ypred, truth=y))

#confusion matrix
confusionMatrix(as.factor(ypred), as.factor(y))

#collecting accuracy on validation data
x<-as.matrix(train[-obs,-1])
y<-as.matrix(reps[-obs])
y[which(y==2)]=0
y<-as.matrix(as.numeric(y))

glm_df<-cbind(y, train[-obs,which(vars_keep!=0)[-1]])

ypred=(predict(lr_ultima,glm_df, type='response')>0.5)+0.0
table(predict=ypred, truth=y)
mean(ypred==y)

xtable(table(predict=ypred, truth=y))

#confusion matrix for validation data
confusionMatrix(as.factor(ypred), as.factor(y))


#
