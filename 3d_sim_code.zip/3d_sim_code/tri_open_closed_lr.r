#reset
rm(list=ls())
old.par <- par(mar = c(0, 0, 0, 0))
par(old.par)

library(xtable) #for table creation for latex
library(caret)#for more info on training rf
library(glmnet)
library(clue)#for predicting kmeans
library(scatterplot3d)#for 3d plot in r
library(Hmisc)#for minor ticks
library(pROC)#for ROC curves

#reporting session info
sessionInfo()
#set seed for reproducability
set.seed(883482)

###########
# control
###########

#shape metrics
cd_1 = read.table('tri_0h_SHAPES.txt', sep=',', header=TRUE)

data = cd_1
Ecc_13<-data$E1/data$E3
Ecc_23<-data$E2/data$E3
data<-cbind(data, Ecc_13, Ecc_23)

#shape metrics
in_1 = read.table('tri_0h_INTENSITY.txt', sep=',', header=TRUE)

in_data = in_1
data<-cbind(data, in_data)


#counts plot
temp<-as.data.frame(data)

#k-means clustering from
#https://www.statmethods.net/advstats/cluster.html
mydata <- scale(temp[,-c(6, 10, 11, 21, 22)] ) # standardize variables
#assume open and closed (2 clusters)
fit <- kmeans(mydata, 2)

rep1_cols = as.character(fit$cluster)
table(rep1_cols)
rep1_cols[which(rep1_cols=='1')]='blue' #closed = blue = 1
rep1_cols[which(rep1_cols=='2')]='green'#green = open = 0

png("tri_0h_kmeans.png", width = 4000, height = 4000)
  plot(temp[,-c(6, 10, 11, 21, 22)], col=rep1_cols)
dev.off()

#setup for model
train<-as.data.frame(cbind(as.factor(fit$cluster),
                          temp[,-c(6, 10, 11, 21, 22)] ))
colnames(train)[1]<-"labs_df"

keep1<-which(train$labs_df==1)
keep2<-which(train$labs_df==2)

#70% for training and 30% for validation
obs_1 = sample(keep1, floor(length(keep1)*0.70), replace=FALSE)
obs_2 = sample(keep2, floor(length(keep2)*0.70), replace=FALSE)

obs<-c(obs_1, obs_2)

x<-as.matrix(train[obs,-1])
y<-as.matrix(train[obs,1])
y[which(y==1)]=1
y[which(y==2)]=0
y<-as.matrix(as.numeric(y))

#perform cv to obtain less variables
tune.out<-cv.glmnet(x,y,family="binomial",type.measure="class", nfolds=10)

#print results
plot(tune.out)
tune.out$lambda.min
#using 0.1 since it seems reasonable across data types
vars_keep<-as.matrix(coef(tune.out, s=0.01))
xtable(vars_keep, digits=4)

shapes = c(16, 2)
shapes <- shapes[as.numeric(train[,1])]

back<-train
colnames(back)[5]<-"S.A."

png("tri_0h_lasso.png", width = 1000, height = 1000)
  plot(back[which(vars_keep!=0)[-1]],
  col=rep1_cols,
  pch=shapes,
  lower.panel=NULL,
  cex.axis=2.5,
  cex.labels=4,
  las=2,
  oma=c(7, 5, 7, 7)
  )
  par(xpd=TRUE)
  legend('bottomleft',
   legend = levels(as.factor(c("Open", "Closed"))),
   col =  c("blue", "green"),
   pch = c(16, 2),
   cex=3
  )
dev.off()

glm_df<-cbind(y, train[obs,which(vars_keep!=0)[-1]])

#build model with non-zero variable
lr_ultima<-glm(y~.,
              data=glm_df,
              family=binomial(),
              control = list(maxit = 50))
summary(lr_ultima)

#variable importance
vi<-varImp(lr_ultima)
vi

ts<-abs(summary(lr_ultima)[['coefficients']][,'z value'])
#removing intercept
t_final<-ts[-1]

#sorting by importance
sort(t_final, decreasing=TRUE)

#usually provided relative to the max
sort(t_final, decreasing=TRUE)/max(t_final)

xtable((as.matrix(sort(t_final, decreasing=TRUE)/max(t_final))) ,
       digits=4)

VI<-sort(t_final, decreasing=TRUE)/max(t_final)
vi_names<-names(VI)
names(VI)[2]<-"S.A."

png("vi_plot_tri_0h.png", width = 1000, height = 1000)
    par(col.axis="black", cex.axis=3, mar=c(12, 12, 5, 5))
    plot(VI, xlab=' ', ylab=" " , xaxt='n', ann=FALSE, type='n' )
    title(main='VI for 0 Hours',
          cex.main=4)
    title(xlab='Variable',
          cex.lab=3.5,
          line=8)
    title(ylab="Relative Variable Importance",
          cex.lab=3.5,
          line=5)
    lines(x=1, VI[1],type='h', col=rgb(255, 255, 0, maxColorValue=255), lwd=100, lend='square')
    lines(x=2, VI[2],type='h', col=rgb(111, 240, 242, maxColorValue=255), lwd=100, lend='square')
    lines(x=3, VI[3],type='h', col=rgb(255, 165, 0, maxColorValue=255), lwd=100, lend='square')
    lines(x=4, VI[4],type='h', col=rgb(18, 54, 25, maxColorValue=255), lwd=100, lend='square')
    axis(side=1, labels=FALSE)
    text(par("usr")[3],
         x=1:6,
         labels = vi_names,
         pos=1,
         xpd=TRUE,
         cex=3)
dev.off()

png("vi_plot_tri_0h.png", width = 1000, height = 1000)
    par(col.axis="black", cex.axis=3, mar=c(12, 12, 5, 5))
    barplot(VI, xlab=' ', ylab=" " ,
            col=c(rgb(255, 255, 0, maxColorValue=255),
                  rgb(111, 240, 242, maxColorValue=255),
                  rgb(255, 165, 0, maxColorValue=255),
                  rgb(18, 54, 25, maxColorValue=255)
                  )
           )
    title(main='VI for 0 Hours',
          cex.main=4)
    title(ylab="Relative Variable Importance",
          cex.lab=3.5,
          line=5)
dev.off()

colors <- rep1_cols
shapes = c(16, 2)
shapes <- shapes[as.numeric(train[,1])]

png("3d_scat_tri_0h.png", width = 400, height = 400)
    s3d<-scatterplot3d(train$Max, train$Surface_Area, train$E1,
                  main="3D Scatterplot of H3K27me3 Control",
                  xlab="Max",
                  ylab="Surface Area",
                  zlab="E1",
                  pch=shapes,
                  color=colors,

                  angle=40)
    legend(s3d$xyz.convert(20, 3500, 500), legend = levels(as.factor(c("Open", "Closed"))),
          col =  c("blue", "green"), pch = c(16, 2))
dev.off()


#output accuracy on training data
ypred=(predict(lr_ultima,glm_df, type='response')>0.5)+0.0
table(predict=ypred, truth=y)
mean(ypred==y)

#confusion matrix
confusionMatrix(as.factor(ypred), as.factor(y))

#collecting accuracy on validation data
y<-as.matrix(train[-obs,1])
y[which(y==1)]=0
y[which(y==2)]=1
glm_df<-cbind(y, train[-obs,which(vars_keep!=0)[-1]])

ypred=(predict(lr_ultima,glm_df, type='response')>0.5)+0.0
table(predict=ypred, truth=y)
mean(ypred==y)

#confusion matrix for validation data
confusionMatrix(as.factor(ypred), as.factor(y))

###########
# 6 hours
###########

#shape metrics
cd_1 = read.table('tri_6h_SHAPES.txt', sep=',', header=TRUE)

data = cd_1
Ecc_13<-data$E1/data$E3
Ecc_23<-data$E2/data$E3
data<-cbind(data, Ecc_13, Ecc_23)

#shape metrics
in_1 = read.table('tri_6h_INTENSITY.txt', sep=',', header=TRUE)

in_data = in_1
data<-cbind(data, in_data)


#counts plot
temp<-as.data.frame(data)

#k-means clustering from
#https://www.statmethods.net/advstats/cluster.html
mydata <- scale(temp[,-c(6, 10, 11, 21, 22)] ) # standardize variables
#assume open and closed (2 clusters)
fit <- kmeans(mydata, 2)

rep1_cols = as.character(fit$cluster)
table(rep1_cols)
rep1_cols[which(rep1_cols=='1')]='green' #green = open = 0
rep1_cols[which(rep1_cols=='2')]='blue'  #closed = blue = 1

png("tri_6h_kmeans.png", width = 4000, height = 4000)
  plot(temp[,-c(6, 10, 11, 21, 22)], col=rep1_cols)
dev.off()

#setup for model
train<-as.data.frame(cbind(as.factor(fit$cluster),
                          temp[,-c(6, 10, 11, 21, 22)] ))
colnames(train)[1]<-"labs_df"

keep1<-which(train$labs_df==1)
keep2<-which(train$labs_df==2)

#70% for training and 30% for validation
obs_1 = sample(keep1, floor(length(keep1)*0.70), replace=FALSE)
obs_2 = sample(keep2, floor(length(keep2)*0.70), replace=FALSE)

obs<-c(obs_1, obs_2)

x<-as.matrix(train[obs,-1])
y<-as.matrix(train[obs,1])
y[which(y==1)]=0
y[which(y==2)]=1
y<-as.matrix(as.numeric(y))

#perform cv to obtain less variables
tune.out<-cv.glmnet(x,y,family="binomial",type.measure="class", nfolds=10)

#print results
plot(tune.out)
tune.out$lambda.min
#using 0.1 since it seems reasonable across data types
vars_keep<-as.matrix(coef(tune.out, s=0.01))
xtable(vars_keep, digits=4)

shapes = c(2, 16)
shapes <- shapes[as.numeric(train[,1])]

back<-train
colnames(back)[5]<-"S.A."

png("tri_6h_lasso.png", width = 1000, height = 1000)
  plot(back[which(vars_keep!=0)[-1]],
  col=rep1_cols,
  pch=shapes,
  lower.panel=NULL,
  cex.axis=2.5,
  cex.labels=4,
  las=2,
  oma=c(7, 5, 7, 7)
  )
  par(xpd=TRUE)
  legend('bottomleft',
   legend = levels(as.factor(c("Open", "Closed"))),
   col =  c("blue", "green"),
   pch = c(16, 2),
   cex=3
  )
dev.off()

glm_df<-cbind(y, train[obs,which(vars_keep!=0)[-1]])

#build model with non-zero variable
lr_ultima<-glm(y~.,
              data=glm_df,
              family=binomial(),
              control = list(maxit = 50))
summary(lr_ultima)
#variable importance
vi<-varImp(lr_ultima)
vi

ts<-abs(summary(lr_ultima)[['coefficients']][,'z value'])
#removing intercept
t_final<-ts[-1]

#sorting by importance
sort(t_final, decreasing=TRUE)

#usually provided relative to the max
sort(t_final, decreasing=TRUE)/max(t_final)

xtable((as.matrix(sort(t_final, decreasing=TRUE)/max(t_final))) ,
       digits=4)

VI<-sort(t_final, decreasing=TRUE)/max(t_final)
vi_names<-names(VI)
names(VI)[1]<-"S.A."

png("vi_plot_tri_6h.png", width = 1000, height = 1000)
    par(col.axis="black", cex.axis=3, mar=c(12, 12, 5, 5))
    plot(VI, xlab=' ', ylab=" " , xaxt='n', ann=FALSE, type='n' )
    title(main='VI for 6 Hours',
          cex.main=4)
    title(xlab='Variable',
          cex.lab=3.5,
          line=8)
    title(ylab="Relative Variable Importance",
          cex.lab=3.5,
          line=5)
    lines(x=1, VI[1],type='h', col=rgb(111, 240, 242, maxColorValue=255), lwd=100, lend='square')
    lines(x=2, VI[2],type='h', col=rgb(255, 255, 0, maxColorValue=255), lwd=100, lend='square')
    lines(x=3, VI[3],type='h', col=rgb(255, 0, 0, maxColorValue=255), lwd=100, lend='square')
    lines(x=4, VI[4],type='h', col=rgb(56, 56, 56, maxColorValue=255), lwd=100, lend='square')
    lines(x=4, VI[4],type='h', col=rgb(255, 255, 255, maxColorValue=255), lwd=70, lend='square')
    lines(x=5, VI[5],type='h', col=rgb(255, 165, 0, maxColorValue=255), lwd=100, lend='square')
    axis(side=1, labels=FALSE)
    text(par("usr")[3],
         x=1:5,
         labels = vi_names,
         pos=1,
         xpd=TRUE,
         cex=3)
dev.off()

png("vi_plot_tri_6h.png", width = 1000, height = 1000)
    par(col.axis="black", cex.axis=3, mar=c(12, 12, 5, 5))
    barplot(VI, xlab=' ', ylab=" " ,
            col=c(rgb(111, 240, 242, maxColorValue=255),
                  rgb(255, 255, 0, maxColorValue=255),
                  rgb(255, 0, 0, maxColorValue=255),
                  rgb(56, 56, 56, maxColorValue=255),
                  rgb(255, 165, 0, maxColorValue=255)
                  )
           )
    title(main='VI for 6 Hours',
          cex.main=4)
    title(ylab="Relative Variable Importance",
          cex.lab=3.5,
          line=5)
  par(new=TRUE)
  barplot(VI, xlab=' ', ylab=" " ,
        col=c(
        rgb(111, 240, 242, maxColorValue=255),
        rgb(255, 255, 0, maxColorValue=255),
        rgb(255, 0, 0, maxColorValue=255),
        rgb(255, 255, 255, maxColorValue=255),
        rgb(255, 165, 0, maxColorValue=255)
        ),
        density=c(-2, -2, -2, 10, -2),
        angle=45, horiz=FALSE)
dev.off()


colors <- rep1_cols
shapes = c(2, 1)
shapes <- shapes[as.numeric(train[,1])]

png("3d_scat_tri_6h.png", width = 400, height = 400)
    s3d<-scatterplot3d(train$Surface_Area, train$Max, train$Skew,
                  main="3D Scatterplot of H3K27me3 6 Hours",
                  xlab="Surface Area",
                  ylab="Max",
                  zlab="Skew",
                  pch=shapes,
                  color=colors,
                  angle=40)
    legend(s3d$xyz.convert(15, 5500, 1.75), legend = levels(as.factor(c("Open", "Closed"))),
          col =  c("blue", "green"), pch = c(16, 2))
dev.off()


#output accuracy on training data
ypred=(predict(lr_ultima,glm_df, type='response')>0.5)+0.0
table(predict=ypred, truth=y)
mean(ypred==y)

#confusion matrix
confusionMatrix(as.factor(ypred), as.factor(y))

#collecting accuracy on validation data
y<-as.matrix(train[-obs,1])
y[which(y==1)]=0
y[which(y==2)]=1
glm_df<-cbind(y, train[-obs,which(vars_keep!=0)[-1]])

ypred=(predict(lr_ultima,glm_df, type='response')>0.5)+0.0
table(predict=ypred, truth=y)
mean(ypred==y)

#confusion matrix for validation data
confusionMatrix(as.factor(ypred), as.factor(y))

###########
# 30 hours
###########

#shape metrics
cd_1 = read.table('tri_30h_SHAPES.txt', sep=',', header=TRUE)

data = cd_1
Ecc_13<-data$E1/data$E3
Ecc_23<-data$E2/data$E3
data<-cbind(data, Ecc_13, Ecc_23)

#shape metrics
in_1 = read.table('tri_30h_INTENSITY.txt', sep=',', header=TRUE)

in_data = in_1
data<-cbind(data, in_data)


#counts plot
temp<-as.data.frame(data)

#k-means clustering from
#https://www.statmethods.net/advstats/cluster.html
mydata <- scale(temp[,-c(6, 10, 11, 21, 22)] ) # standardize variables
#assume open and closed (2 clusters)
fit <- kmeans(mydata, 2)

rep1_cols = as.character(fit$cluster)
table(rep1_cols)
rep1_cols[which(rep1_cols=='1')]='green' #green = open = 0
rep1_cols[which(rep1_cols=='2')]='blue'  #closed = blue = 1

png("tri_30h_kmeans.png", width = 4000, height = 4000)
  plot(temp[,-c(6, 10, 11, 21, 22)], col=rep1_cols)
dev.off()

#setup for model
train<-as.data.frame(cbind(as.factor(fit$cluster),
                          temp[,-c(6, 10, 11, 21, 22)] ))
colnames(train)[1]<-"labs_df"

keep1<-which(train$labs_df==1)
keep2<-which(train$labs_df==2)

#70% for training and 30% for validation
obs_1 = sample(keep1, floor(length(keep1)*0.70), replace=FALSE)
obs_2 = sample(keep2, floor(length(keep2)*0.70), replace=FALSE)

obs<-c(obs_1, obs_2)

x<-as.matrix(train[obs,-1])
y<-as.matrix(train[obs,1])
y[which(y==1)]=0
y[which(y==2)]=1
y<-as.matrix(as.numeric(y))

#perform cv to obtain less variables
tune.out<-cv.glmnet(x,y,family="binomial",type.measure="class", nfolds=10)

#print results
plot(tune.out)
tune.out$lambda.min
#using 0.1 since it seems reasonable across data types
vars_keep<-as.matrix(coef(tune.out, s=0.01))
xtable(vars_keep, digits=4)

shapes = c(2, 16)
shapes <- shapes[as.numeric(train[,1])]

back<-train
colnames(back)[5]<-"S.A."

png("tri_30h_lasso.png", width = 1000, height = 1000)
  plot(back[which(vars_keep!=0)[-1]],
  col=rep1_cols,
  pch=shapes,
  lower.panel=NULL,
  cex.axis=2.5,
  cex.labels=4,
  las=2,
  oma=c(7, 5, 7, 7)
  )
  par(xpd=TRUE)
  legend('bottomleft',
   legend = levels(as.factor(c("Open", "Closed"))),
   col =  c("blue", "green"),
   pch = c(16, 2),
   cex=3
  )
dev.off()

glm_df<-cbind(y, train[obs,which(vars_keep!=0)[-1]])

#build model with non-zero variable
lr_ultima<-glm(y~.,
              data=glm_df,
              family=binomial(),
              control = list(maxit = 50))
summary(lr_ultima)

#variable importance
vi<-varImp(lr_ultima)
vi

ts<-abs(summary(lr_ultima)[['coefficients']][,'z value'])
#removing intercept
t_final<-ts[-1]

#sorting by importance
sort(t_final, decreasing=TRUE)

#usually provided relative to the max
sort(t_final, decreasing=TRUE)/max(t_final)

xtable((as.matrix(sort(t_final, decreasing=TRUE)/max(t_final))) ,
       digits=4)

VI<-sort(t_final, decreasing=TRUE)/max(t_final)
vi_names<-names(VI)
names(VI)[1]<-"S.A."

png("vi_plot_tri_30h.png", width = 1300, height = 1300)
    par(col.axis="black", cex.axis=3, mar=c(12, 12, 5, 5))
    plot(VI, xlab=' ', ylab=" " , xaxt='n', ann=FALSE, type='n' )
    title(main='VI for 30 Hours',
          cex.main=4)
    title(xlab='Variable',
          cex.lab=3.5,
          line=8)
    title(ylab="Relative Variable Importance",
          cex.lab=3.5,
          line=5)
        lines(x=1, VI[1],type='h', col=rgb(111, 240, 242, maxColorValue=255), lwd=100, lend='square')
        lines(x=2, VI[2],type='h', col=rgb(255, 255, 0, maxColorValue=255), lwd=100, lend='square')
        lines(x=3, VI[3],type='h', col=rgb(255, 0, 0, maxColorValue=255), lwd=100, lend='square')
        lines(x=4, VI[4],type='h', col=rgb(56, 56, 56, maxColorValue=255), lwd=100, lend='square')
        lines(x=4, VI[4],type='h', col=rgb(255, 255, 255, maxColorValue=255), lwd=70, lend='square')
        lines(x=5, VI[5],type='h', col=rgb(18, 54, 25, maxColorValue=255), lwd=100, lend='square')
        lines(x=6, VI[5],type='h', col=rgb(255, 165, 0, maxColorValue=255), lwd=100, lend='square')
        lines(x=7, VI[5],type='h', col=rgb(255, 179, 217, maxColorValue=255), lwd=100, lend='square')
    axis(side=1, labels=FALSE)
    text(par("usr")[3],
         x=1:7,
         labels = vi_names,
         pos=1,
         xpd=TRUE,
         cex=3)
dev.off()

png("vi_plot_tri_30h.png", width = 1300, height = 1300)
    par(col.axis="black", cex.axis=3, mar=c(12, 12, 5, 5))
    barplot(VI, xlab=' ', ylab=" " , #ann=FALSE,# type='n',
            col=c(rgb(111, 240, 242, maxColorValue=255),
                  rgb(255, 255, 0, maxColorValue=255),
                  rgb(255, 0, 0, maxColorValue=255),
                  rgb(56, 56, 56, maxColorValue=255),
                  rgb(18, 54, 25, maxColorValue=255),
                  rgb(255, 165, 0, maxColorValue=255),
                  rgb(255, 179, 217, maxColorValue=255)
                  )
           )
    title(main='VI for 30 Hours',
          cex.main=4)
    title(ylab="Relative Variable Importance",
          cex.lab=3.5,
          line=5)
  par(new=TRUE)
  barplot(VI, xlab=' ', ylab=" " ,
        col=c(
        rgb(111, 240, 242, maxColorValue=255),
        rgb(255, 255, 0, maxColorValue=255),
        rgb(255, 0, 0, maxColorValue=255),
        rgb(255, 255, 255, maxColorValue=255),
        rgb(18, 54, 25, maxColorValue=255),
        rgb(255, 165, 0, maxColorValue=255),
        rgb(255, 179, 217, maxColorValue=255)
        ),
        density=c(-2, -2, -2, 10, -2, -2, -2),
        angle=45, horiz=FALSE)
dev.off()


colors <- rep1_cols
shapes = c(2, 16)
shapes <- shapes[as.numeric(train[,1])]

png("3d_scat_tri_30h.png", width = 400, height = 400)
    s3d<-scatterplot3d(train$Surface_Area, train$Max, train$Skew,
                  main="3D Scatterplot of H3K27me3 30 Hours",
                  xlab="Surface Area",
                  ylab="Max",
                  zlab="Skew",
                  pch=shapes,
                  color=colors,
                  angle=40)
    legend(s3d$xyz.convert(500, 0, 0), legend = levels(as.factor(c("Open", "Closed"))),
          col =  c("blue", "green"), pch = c(16, 2))
dev.off()


#output accuracy on training data
ypred=(predict(lr_ultima,glm_df, type='response')>0.5)+0.0
table(predict=ypred, truth=y)
mean(ypred==y)

#confusion matrix
confusionMatrix(as.factor(ypred), as.factor(y))

#collecting accuracy on validation data
y<-as.matrix(train[-obs,1])
y[which(y==1)]=0
y[which(y==2)]=1
glm_df<-cbind(y, train[-obs,which(vars_keep!=0)[-1]])

ypred=(predict(lr_ultima,glm_df, type='response')>0.5)+0.0
table(predict=ypred, truth=y)
mean(ypred==y)

#confusion matrix for validation data
confusionMatrix(as.factor(ypred), as.factor(y))


#
