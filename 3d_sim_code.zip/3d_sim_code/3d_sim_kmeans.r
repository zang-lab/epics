#reset
rm(list=ls())
old.par <- par(mar = c(0, 0, 0, 0))
par(old.par)

library(xtable) #for table creation for latex
library(clue)#for predicting kmeans
library(matrixStats)#for rowQuantiles

#loading custom functions
source('r_functions.r')

#reporting session info
sessionInfo()
#set seed for reproducability
set.seed(883482)

#metrics for evaluation
mets<-matrix(nrow=3, ncol=3, data=0)
colnames(mets)<-c("JI", "Acc.", "Balanced Acc.")
rownames(mets)<-c("Control", "6 Hours", "30 Hours")


###############
#Control
###############

#shape metrics
cd_1 = read.table('tri_0h_SHAPES.txt', sep=',', header=TRUE)

data = cd_1
Ecc_13<-data$E1/data$E3
Ecc_23<-data$E2/data$E3
data<-cbind(data, Ecc_13, Ecc_23)

#shape metrics
in_1 = read.table('tri_0h_INTENSITY.txt', sep=',', header=TRUE)

in_data = in_1
data<-cbind(data, in_data)


#counts plot
temp<-as.data.frame(data)


#k-means clustering from
#https://www.statmethods.net/advstats/cluster.html
mydata <- scale(temp[,-c(6, 10, 11, 21, 22)] ) # standardize variables
#assume open and closed (2 clusters)
fit <- kmeans(mydata, 2)


rep1_cols = as.numeric(fit$cluster)
table(rep1_cols)

vals_ones<-which(rep1_cols==1)
vals_twos<-which(rep1_cols==2)

m1<-mean(temp$Mean[vals_ones])
m2<-mean(temp$Mean[vals_twos])

m1
m2

if(m1>m2){

  rep1_cols[which(rep1_cols==1)]=1 #closed = blue = 1
  rep1_cols[which(rep1_cols==2)]=0#green = open = 0

}else{

  rep1_cols[which(rep1_cols==1)]=0#green = open = 0
  rep1_cols[which(rep1_cols==2)]=1 #closed = blue = 1


}


##########################
#bootstrap Jaccard Index
##########################

#number of times performing bootstrap
num_times=100
#object to hold all jaccard indexes
ji<-matrix(nrow=num_times, ncol=1, data=0)
#accuracy
acc<-matrix(nrow=num_times, ncol=1, data=0)
#balanced accuracy
b_acc<-matrix(nrow=num_times, ncol=1, data=0)
#coefficients
coefs<-matrix(nrow=num_times, ncol=5, data=0)
#number of samples to take
num_samps<-2500

for (i in 1:num_times) {
    #selecting new bootstrap sample
    new_samp_vals=sample(x=1:dim(mydata)[1], size=num_samps, replace=TRUE)
    new_samp = mydata[new_samp_vals,]
    #forming clusters via k-means
    new_fit <- kmeans(new_samp, 2)
    #predicting classes on original data
    new_pred<-cl_predict(new_fit, mydata)
    #assigning cluster appropriately using automation
    rep1_new = as.numeric(new_pred)
    vals_ones<-which(rep1_new==1)
    vals_twos<-which(rep1_new==2)
    m1<-mean(temp$Mean[vals_ones])
    m2<-mean(temp$Mean[vals_twos])
    if(m1>m2){

      rep1_new[which(rep1_new==1)]=1 #closed = blue = 1
      rep1_new[which(rep1_new==2)]=0#green = open = 0

    }else{


      rep1_new[which(rep1_new==1)]=0#green = open = 0
      rep1_new[which(rep1_new==2)]=1 #closed = blue = 1

    }

    #setup for model
    train<-as.data.frame(cbind(as.factor(rep1_new[new_samp_vals]),
                              temp[new_samp_vals,-c(6, 10, 11, 21, 22)] ))
    colnames(train)[1]<-"y"

    keep1<-which(train$labs_df==1)
    keep2<-which(train$labs_df==2)

    lr_ultima<-glm(y~E1+Surface_Area+Max+Min,
                  data=train,
                  family=binomial(),
                  control = list(maxit = 50))

    coefs[i,]<-(summary(lr_ultima)[['coefficients']][,'Estimate'])

    #saving metrics
    ji[i,1]<-jaccard(rep1_new, rep1_cols)
    acc[i,1]<-mean(rep1_new==rep1_cols)
    b_acc[i,1]<-bal_acc(rep1_new,rep1_cols)
}

mets[1,1]<-mean(ji)
sd(ji)
mets[1,2]<-mean(acc)
mets[1,3]<-mean(b_acc)

colnames(coefs)<-names(summary(lr_ultima)[['coefficients']][,'Estimate'])
cbind(colMeans(coefs),colQuantiles(coefs, p=c(0.025, 0.975)))

xtable(as.matrix( cbind(colMeans(coefs),colQuantiles(coefs, p=c(0.025, 0.975))) ))

###############
#6 hours
###############

#shape metrics
cd_1 = read.table('tri_6h_SHAPES.txt', sep=',', header=TRUE)

data = cd_1
Ecc_13<-data$E1/data$E3
Ecc_23<-data$E2/data$E3
data<-cbind(data, Ecc_13, Ecc_23)

#shape metrics
in_1 = read.table('tri_6h_INTENSITY.txt', sep=',', header=TRUE)

in_data = in_1
data<-cbind(data, in_data)

#counts plot
temp<-as.data.frame(data)

#k-means clustering from
#https://www.statmethods.net/advstats/cluster.html
mydata <- scale(temp[,-c(6, 10, 11, 21, 22)] ) # standardize variables
#remove reps
mydata<-mydata[,-dim(mydata)[2]]
#assume open and closed (2 clusters)
fit <- kmeans(mydata, 2)

rep1_cols = as.numeric(fit$cluster)
table(rep1_cols)

vals_ones<-which(rep1_cols==1)
vals_twos<-which(rep1_cols==2)

m1<-mean(temp$Mean[vals_ones])
m2<-mean(temp$Mean[vals_twos])

m1
m2

if(m1>m2){

  rep1_cols[which(rep1_cols==1)]=1 #closed = blue = 1
  rep1_cols[which(rep1_cols==2)]=0#green = open = 0

}else{
    rep1_cols[which(rep1_cols==1)]=0#green = open = 0
  rep1_cols[which(rep1_cols==2)]=1 #closed = blue = 1


}


##########################
#bootstrap Jaccard Index
##########################

#number of times performing bootstrap
num_times=100
#object to hold all jaccard indexes
ji<-matrix(nrow=num_times, ncol=1, data=0)
#accuracy
acc<-matrix(nrow=num_times, ncol=1, data=0)
#balanced accuracy
b_acc<-matrix(nrow=num_times, ncol=1, data=0)
#coefficients
coefs<-matrix(nrow=num_times, ncol=6, data=0)
coefs2<-matrix(nrow=num_times, ncol=4, data=0)
#number of samples to take
num_samps<-2500

for (i in 1:num_times) {
    #selecting new bootstrap sample
    new_samp_vals=sample(x=1:dim(mydata)[1], size=num_samps, replace=TRUE)
    new_samp = mydata[new_samp_vals,]
    #forming clusters via k-means
    new_fit <- kmeans(new_samp, 2)
    #predicting classes on original data
    new_pred<-cl_predict(new_fit, mydata)
    #assigning cluster appropriately using automation
    rep1_new = as.numeric(new_pred)
    vals_ones<-which(rep1_new==1)
    vals_twos<-which(rep1_new==2)
    m1<-mean(temp$Mean[vals_ones])
    m2<-mean(temp$Mean[vals_twos])
    if(m1>m2){

      rep1_new[which(rep1_new==1)]=1 #closed = blue = 1
      rep1_new[which(rep1_new==2)]=0#green = open = 0

    }else{
        rep1_new[which(rep1_new==1)]=0#green = open = 0
      rep1_new[which(rep1_new==2)]=1 #closed = blue = 1


    }

    #setup for model
    train<-as.data.frame(cbind(as.factor(rep1_new[new_samp_vals]),
                        temp[new_samp_vals,-c(6, 10, 11, 21, 22)] ))
    colnames(train)[1]<-"y"

    keep1<-which(train$labs_df==1)
    keep2<-which(train$labs_df==2)

    lr_ultima<-glm(y~E1+Surface_Area+SD+Max+Skew,
    #lr_ultima<-glm(y~Surface_Area+SD+Max+Skew,
                  data=train,
                  family=binomial(),
                  control = list(maxit = 200))

    coefs[i,]<-(summary(lr_ultima)[['coefficients']][,'Estimate'])

    lr_ultima2<-glm(y~Surface_Area+Max+Skew,
                  data=train,
                  family=binomial(),
                  control = list(maxit = 200))

    coefs2[i,]<-(summary(lr_ultima2)[['coefficients']][,'Estimate'])

    ji[i,1]<-jaccard(rep1_new, rep1_cols)
    acc[i,1]<-mean(rep1_new==rep1_cols)
    b_acc[i,1]<-bal_acc(rep1_new,rep1_cols)
}

mets[2,1]<-mean(ji)
sd(ji)
mets[2,2]<-mean(acc)
mets[2,3]<-mean(b_acc)

colnames(coefs)<-names(summary(lr_ultima)[['coefficients']][,'Estimate'])

cbind(colMeans(coefs),colQuantiles(coefs, p=c(0.025, 0.975)))

xtable(as.matrix( cbind(colMeans(coefs),colQuantiles(coefs, p=c(0.025, 0.975))) ))

#with removed variable

colnames(coefs2)<-names(summary(lr_ultima2)[['coefficients']][,'Estimate'])

cbind(colMeans(coefs2),colQuantiles(coefs2, p=c(0.025, 0.5, 0.975)))

xtable(as.matrix( cbind(colMeans(coefs2),colQuantiles(coefs2, p=c(0.025, 0.5, 0.975))) ))

###############
#30 hours
###############

#shape metrics
cd_1 = read.table('tri_30h_SHAPES.txt', sep=',', header=TRUE)

data = cd_1
Ecc_13<-data$E1/data$E3
Ecc_23<-data$E2/data$E3
data<-cbind(data, Ecc_13, Ecc_23)

#shape metrics
in_1 = read.table('tri_30h_INTENSITY.txt', sep=',', header=TRUE)

in_data = in_1
data<-cbind(data, in_data)

#counts plot
temp<-as.data.frame(data)

#k-means clustering from
#https://www.statmethods.net/advstats/cluster.html
mydata <- scale(temp[,-c(6, 10, 11, 21, 22)] ) # standardize variables
#remove reps
mydata<-mydata[,-dim(mydata)[2]]
#assume open and closed (2 clusters)
fit <- kmeans(mydata, 2)

rep1_cols = as.numeric(fit$cluster)
table(rep1_cols)

vals_ones<-which(rep1_cols==1)
vals_twos<-which(rep1_cols==2)

m1<-mean(temp$Mean[vals_ones])
m2<-mean(temp$Mean[vals_twos])

m1
m2

if(m1>m2){

  rep1_cols[which(rep1_cols==1)]=1 #closed = blue = 1
  rep1_cols[which(rep1_cols==2)]=0#green = open = 0

}else{
    rep1_cols[which(rep1_cols==1)]=0#green = open = 0
  rep1_cols[which(rep1_cols==2)]=1 #closed = blue = 1


}


##########################
#bootstrap Jaccard Index
##########################

#number of times performing bootstrap
num_times=100
#object to hold all jaccard indexes
ji<-matrix(nrow=num_times, ncol=1, data=0)
#accuracy
acc<-matrix(nrow=num_times, ncol=1, data=0)
#balanced accuracy
b_acc<-matrix(nrow=num_times, ncol=1, data=0)
#coefficients
coefs<-matrix(nrow=num_times, ncol=8, data=0)
#number of samples to take
num_samps<-2500

for (i in 1:num_times) {
    #selecting new bootstrap sample
    new_samp_vals=sample(x=1:dim(mydata)[1], size=num_samps, replace=TRUE)
    new_samp = mydata[new_samp_vals,]
    #forming clusters via k-means
    new_fit <- kmeans(new_samp, 2)
    #predicting classes on original data
    new_pred<-cl_predict(new_fit, mydata)
    #assigning cluster appropriately using automation
    rep1_new = as.numeric(new_pred)
    vals_ones<-which(rep1_new==1)
    vals_twos<-which(rep1_new==2)
    m1<-mean(temp$Mean[vals_ones])
    m2<-mean(temp$Mean[vals_twos])
    if(m1>m2){

      rep1_new[which(rep1_new==1)]=1 #closed = blue = 1
      rep1_new[which(rep1_new==2)]=0#green = open = 0

    }else{
        rep1_new[which(rep1_new==1)]=0#green = open = 0
      rep1_new[which(rep1_new==2)]=1 #closed = blue = 1


    }

    #setup for model
    train<-as.data.frame(cbind(as.factor(rep1_new[new_samp_vals]),
                        temp[new_samp_vals,-c(6, 10, 11, 21, 22)] ))
    colnames(train)[1]<-"y"

    keep1<-which(train$labs_df==1)
    keep2<-which(train$labs_df==2)

    lr_ultima<-glm(y~E1+E3+Surface_Area+SD+Max+Min+Skew,
                  data=train,
                  family=binomial(),
                  control = list(maxit = 50))

    coefs[i,]<-(summary(lr_ultima)[['coefficients']][,'Estimate'])

    ji[i,1]<-jaccard(rep1_new, rep1_cols)
    acc[i,1]<-mean(rep1_new==rep1_cols)
    b_acc[i,1]<-bal_acc(rep1_new,rep1_cols)
}

mets[3,1]<-mean(ji)
sd(ji)
mets[3,2]<-mean(acc)
mets[3,3]<-mean(b_acc)

colnames(coefs)<-names(summary(lr_ultima)[['coefficients']][,'Estimate'])
cbind(colMeans(coefs),colQuantiles(coefs, p=c(0.025, 0.975)))

xtable(as.matrix( cbind(colMeans(coefs),colQuantiles(coefs, p=c(0.025, 0.975))) ))

#display results
mets

xtable(mets)

#
