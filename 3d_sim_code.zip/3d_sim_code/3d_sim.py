#test file for 3d_tif.py
import md_tif as md
import imageio as ii
import numpy as np
import scipy.ndimage as nd

###############
# control
###############

fname='Fig4/Fig4/A_19AM05-03_1_Ctrl_003.tif'

#read data
adata = md.read(fname)

#extract the blue (dapi staining)
blue = adata[:,2,:,:]
#extract the red (H3K27me3)
red = adata[:,0,:,:]
check = ((red - red.min()+1) * (1/(red.max() - red.min()) * 255))
ii.volsave('temp.tif', check.astype(np.uint8)*(255))#targets are black
red_smoothed = md.Smooth_loaded(adata=red, size=1,sd=1, save_img=False)

#smooth the image dapi staining
adata = md.Smooth_loaded(adata=blue,save_img=True)

#extract shape
#get quantiles to extract object
low = np.quantile(blue, 0.80)

#extarct shape
shape = (blue>low)+0.0
ii.volsave('example/binary_example.tif', shape.astype(np.uint8)*(255))

#isolate
#extarct largest object
b,n = nd.label(shape)
simp = np.hstack(b)
locs= np.nonzero( simp )
counts=np.bincount(simp [locs] )
vals=counts.argsort()[-3:][::-1]
clist = list(map(lambda x: b==x, (0,vals[0]) ))
edata = shape+0.0
ii.volsave('example/largest_example.tif', edata.astype(np.uint8)*(255))
#final image
edata = ((b==vals[0]))+0.0
shape = nd.binary_fill_holes(edata)
shape = nd.binary_dilation(shape, iterations=5)
shape = nd.binary_fill_holes(shape)
ii.volsave('example/isolate1_example.tif', shape.astype(np.uint8)*(255))

#rescale
check = ((red_smoothed - red_smoothed.min()+1) * (1/(red_smoothed.max() - red_smoothed.min()) * 255))
#apply mask and thresholding to extract potential target signals
sigs = ((255-check.astype(np.uint8)*(255))*shape)>59
sigs = sigs +0.0
ii.volsave('temp.tif', sigs.astype(np.uint8)*(255))#targets are black

#extracting each potential signal
b,n = nd.label(sigs)

#check to ensure that each value corresponds to a connected object

temp = b==12
temp = temp +0.0

ii.volsave('temp.tif',  temp.astype(np.uint8)*(255))

#it works, so now we should extend b, and then extract metrics from each object
#in b
#extend z dimension to proper size
extend = md.Construct(img=b, save_img=False, add=1)
check = ((extend - extend.min()+1) * (1/(extend.max() - extend.min()) * 255))
ii.volsave('temp.tif',  check.astype(np.uint8)*(255))
red_extend = md.Construct(img=red, save_img=False, add=1)

#for loop to extract all the metrics for each object
#object ot hold shape metrics
shape_mets = []
#object to hold intensity metrics
tent_mets = []

print('Control')
print('n=',n)
for i in range(1,n):
    print("CD number:",i)
    temp = extend==i
    temp = temp +0.0
    shape_mets.append(md.Shapes(temp))
    temp2 = temp*red_extend
    tent_mets.append(md.Intensity(pic=temp2, shape=temp))


#save results as txt file
name_shape = "tri_0h_SHAPES.txt"
name_tents = "tri_0h_INTENSITY.txt"
np.savetxt(name_shape, np.vstack(shape_mets), delimiter=',', header="SP, W_EI, B_EI, Surface_Area, Sphericity, Eccentricity, E1, E2, E3", comments='')
np.savetxt(name_tents, np.vstack(tent_mets), delimiter=',', header="Mean, SD, Med, Min, Q1, Q3, Max, Skew, Kurt, PercGrt2_4, PercGrt3", comments='')


###############
# 6 hours
###############

fname='Fig4/Fig4/B_19AM05-03_2__6h_011.tif'

#read data
adata = md.read(fname)

#extract the blue (dapi staining)
blue = adata[:,2,:,:]
#extract the red (H3K27me3)
red = adata[:,0,:,:]
check = ((red - red.min()+1) * (1/(red.max() - red.min()) * 255))
ii.volsave('temp.tif', check.astype(np.uint8)*(255))#targets are black
red_smoothed = md.Smooth_loaded(adata=red, size=1,sd=1, save_img=False)

#smooth the image dapi staining
adata = md.Smooth_loaded(adata=blue,save_img=True)

#extract shape
#get quantiles to extract object
low = np.quantile(blue, 0.80)

#extarct shape
shape = (blue>low)+0.0
ii.volsave('example/binary_example.tif', shape.astype(np.uint8)*(255))

#isolate
#extarct largest object
b,n = nd.label(shape)
simp = np.hstack(b)
locs= np.nonzero( simp )
counts=np.bincount(simp [locs] )
vals=counts.argsort()[-3:][::-1]
clist = list(map(lambda x: b==x, (0,vals[0]) ))
edata = shape+0.0
ii.volsave('example/largest_example.tif', edata.astype(np.uint8)*(255))
#final image
edata = ((b==vals[0]))+0.0
shape = nd.binary_fill_holes(edata)
shape = nd.binary_dilation(shape, iterations=5)
shape = nd.binary_fill_holes(shape)
ii.volsave('example/isolate1_example.tif', shape.astype(np.uint8)*(255))

#rescale
check = ((red_smoothed - red_smoothed.min()+1) * (1/(red_smoothed.max() - red_smoothed.min()) * 255))
#apply mask and thresholding to extract potential target signals
sigs = ((255-check.astype(np.uint8)*(255))*shape)>59
sigs = sigs +0.0
ii.volsave('temp.tif', sigs.astype(np.uint8)*(255))#targets are black

#extracting each potential signal
b,n = nd.label(sigs)

#check to ensure that each value corresponds to a connected object

temp = b==12
temp = temp +0.0

ii.volsave('temp.tif',  temp.astype(np.uint8)*(255))

#it works, so now we should extend b, and then extract metrics from each object
#in b
#extend z dimension to proper size
extend = md.Construct(img=b, save_img=False, add=1)
check = ((extend - extend.min()+1) * (1/(extend.max() - extend.min()) * 255))
ii.volsave('temp.tif',  check.astype(np.uint8)*(255))
red_extend = md.Construct(img=red, save_img=False, add=1)

#for loop to extract all the metrics for each object
#object ot hold shape metrics
shape_mets = []
#object to hold intensity metrics
tent_mets = []

print('6 Hours')
print('n=',n)
for i in range(1,n):
    print("CD number:",i)
    temp = extend==i
    temp = temp +0.0
    shape_mets.append(md.Shapes(temp))
    temp2 = temp*red_extend
    tent_mets.append(md.Intensity(pic=temp2, shape=temp))


#save results as txt file
name_shape = "tri_6h_SHAPES.txt"
name_tents = "tri_6h_INTENSITY.txt"
np.savetxt(name_shape, np.vstack(shape_mets), delimiter=',', header="SP, W_EI, B_EI, Surface_Area, Sphericity, Eccentricity, E1, E2, E3", comments='')
np.savetxt(name_tents, np.vstack(tent_mets), delimiter=',', header="Mean, SD, Med, Min, Q1, Q3, Max, Skew, Kurt, PercGrt2_4, PercGrt3", comments='')

###############
# 30 hours
###############

fname='Fig4/Fig4/C_19AM05-03_3_30h_MLN_019.tif'

#read data
adata = md.read(fname)

#extract the blue (dapi staining)
blue = adata[:,2,:,:]
#extract the red (H3K27me3)
red = adata[:,0,:,:]
check = ((red - red.min()+1) * (1/(red.max() - red.min()) * 255))
ii.volsave('temp.tif', check.astype(np.uint8)*(255))#targets are black
red_smoothed = md.Smooth_loaded(adata=red, size=1,sd=1, save_img=False)
ii.volsave('example/red_smoother.tif', check.astype(np.uint8)*(255))#

#smooth the image dapi staining
adata = md.Smooth_loaded(adata=blue,save_img=True)

#extract shape
#get quantiles to extract object
low = np.quantile(blue, 0.80)

#extarct shape
shape = (blue>low)+0.0
ii.volsave('example/binary_example.tif', shape.astype(np.uint8)*(255))

#isolate
#extarct largest object
b,n = nd.label(shape)
simp = np.hstack(b)
locs= np.nonzero( simp )
counts=np.bincount(simp [locs] )
vals=counts.argsort()[-3:][::-1]
clist = list(map(lambda x: b==x, (0,vals[0]) ))
edata = shape+0.0
ii.volsave('example/largest_example.tif', edata.astype(np.uint8)*(255))
#final image
edata = ((b==vals[0]))+0.0
shape = nd.binary_fill_holes(edata)
shape = nd.binary_dilation(shape, iterations=5)
shape = nd.binary_fill_holes(shape)
ii.volsave('example/isolate1_example.tif', shape.astype(np.uint8)*(255))

#rescale
check = ((red_smoothed - red_smoothed.min()+1) * (1/(red_smoothed.max() - red_smoothed.min()) * 255))
#apply mask and thresholding to extract potential target signals
sigs = ((255-check.astype(np.uint8)*(255))*shape)>59
sigs = sigs +0.0
ii.volsave('temp.tif', sigs.astype(np.uint8)*(255))#targets are black

#extracting each potential signal
b,n = nd.label(sigs)

#check to ensure that each value corresponds to a connected object

temp = b==12
temp = temp +0.0

ii.volsave('temp.tif',  temp.astype(np.uint8)*(255))

#it works, so now we should extend b, and then extract metrics from each object
#in b
#extend z dimension to proper size
extend = md.Construct(img=b, save_img=False, add=1)
check = ((extend - extend.min()+1) * (1/(extend.max() - extend.min()) * 255))
ii.volsave('temp.tif',  check.astype(np.uint8)*(255))
red_extend = md.Construct(img=red, save_img=False, add=1)

#for loop to extract all the metrics for each object
#object ot hold shape metrics
shape_mets = []
#object to hold intensity metrics
tent_mets = []

print('30 Hours')
print('n=',n)
for i in range(1,n):
    print("CD number:",i)
    temp = extend==i
    temp = temp +0.0
    shape_mets.append(md.Shapes(temp))
    temp2 = temp*red_extend
    tent_mets.append(md.Intensity(pic=temp2, shape=temp))

#save results as txt file
name_shape = "tri_30h_SHAPES.txt"
name_tents = "tri_30h_INTENSITY.txt"
np.savetxt(name_shape, np.vstack(shape_mets), delimiter=',', header="SP, W_EI, B_EI, Surface_Area, Sphericity, Eccentricity, E1, E2, E3", comments='')
np.savetxt(name_tents, np.vstack(tent_mets), delimiter=',', header="Mean, SD, Med, Min, Q1, Q3, Max, Skew, Kurt, PercGrt2_4, PercGrt3", comments='')


#
