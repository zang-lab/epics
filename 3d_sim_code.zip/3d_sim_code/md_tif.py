#functions for extracting 3D shapes from z-stack of .tif files 

import imageio as ii
import numpy as np
import scipy.ndimage as nd
from skimage.morphology import disk
from skimage.filters import threshold_otsu, rank
from skimage.feature import corner_harris, corner_peaks
import scipy.misc as sm
from pathlib import Path
from sklearn import cluster
from sklearn import metrics
from sklearn.cluster import KMeans, SpectralClustering, DBSCAN
from kneed import KneeLocator
from skimage.feature import peak_local_max
from scipy import stats
import matplotlib.pyplot as plt
import collections
import os

#function to read tif files
def read(fname):
    adata = ii.volread(fname)
    return adata

#save image
def save(pic, name):
    ii.volsave(name, pic)

#smooth the image
def Smooth(fname='example.tif',size=2,sd=0.1, save_img=False, save_dir=None):
    #read in tif
    print(fname)
    adata = ii.volread(fname)
    #bin pixels
    bdata = nd.minimum_filter(adata, size=size)
    #smooth the image via gaussian smoothing
    bdata = nd.gaussian_filter(bdata, sd)
    if save_img==True:
        save_dir='example/smooth_'+fname
        Path("example").mkdir(parents=True, exist_ok=True)
        ii.volsave(save_dir, bdata)
    return bdata

#smooth the image already loaded
def Smooth_loaded(adata,size=2,sd=0.1, save_img=False, save_dir=None, fname='example.tif'):
    #bin pixels
    bdata = nd.minimum_filter(adata, size=size)
    #smooth the image via gaussian smoothing
    bdata = nd.gaussian_filter(bdata, sd)
    if save_img==True:
        save_dir='example/smooth_'+fname
        Path("example").mkdir(parents=True, exist_ok=True)
        ii.volsave(save_dir, bdata)
    return bdata

#apply threshold to binarize image
def Otsu(img, save_img=False, save_dir=None, fname='example.tif'):
    cdata = img +0.0
    #get otsu threshold value for each slice
    for i in range(0,img.shape[0]):
        cdata[i] = threshold_otsu(img[i])
    #apply threshold found via otsu
    ddata = (img<=cdata)+0
    #save image option
    if save_img==True:
        save_dir='example/binary_'+fname
        Path("example").mkdir(parents=True, exist_ok=True)
        ii.volsave(save_dir, ddata.astype(np.uint8)*(255))
    return ddata

#second pass of isolation with erosion
def Isolate2(img, iterations=3, save_img=False, save_dir=None, fname='example.tif'):
    #apply erosion to remove spurios signals
    fdata = (nd.binary_erosion(img , iterations=iterations))+0.0
    #isolate each of the objects in the input image
    b,n = nd.label(fdata)
    simp = np.hstack(b)
    locs= np.nonzero( simp )
    counts=np.bincount(simp [locs] )
    vals=counts.argsort()[-3:][::-1]
    clist = list(map(lambda x: b==x, (0,vals[0]) ))
    edata = img+0.0
    #final image
    edata = ((b==vals[0]))+0.0
    #save image option
    if save_img==True:
        save_dir='example/isolate2_'+fname
        Path("example").mkdir(parents=True, exist_ok=True)
        ii.volsave('example/erosion_'+fname, (fdata).astype(np.uint8)*255 )
        ii.volsave(save_dir, edata.astype(np.uint8)*(255))
    return edata

#function to compore original image with mask
def ApplyMask(mask, save_img=False, save_dir=None, fname='example.tif'):
    #load image
    adata = ii.volread(fname)
    #apply mask to original image
    ultima = (adata*mask)+0.0
    #save image option
    if save_img==True:
        save_dir='example/check_'+fname
        Path("example").mkdir(parents=True, exist_ok=True)
        ii.volsave(save_dir, ultima.astype(np.uint16))
    return ultima

#function to add slices to z-stack to provide more accurate representation of object
def Construct(img, add=2, save_img=False, save_dir=None, fname='example.tif'):
    #get shape of tif file
    z,v,h=img.shape
    #correcting code
    #add = add+1
    #calculating new number of z-slices
    # ( additional slices on both sides except the top and bottom of .tif )
    # + (top and bottom additional slices twice)
    z_prime = z-2
    z2 = 2+(2*add)+ (( (2*add)+1 )*z_prime)
    temp = ( (2*add)+1 )*z_prime
    ultima = np.zeros((z2,v,h))
    for i in range(0,add+1):
        ultima[i] = img[0]
    c=add+1
    for j in range(1, z-1):
        i=add+0
        while i <=(2*add+1):
            ultima[c]=img[j]
            c+=1
            i+=1
    for i in range(temp+(1+add),z2):
        ultima[i] = img[-1]
    #save image option
    if save_img==True:
        save_dir='example/extend_'+fname
        Path("example").mkdir(parents=True, exist_ok=True)
        ii.volsave(save_dir, ultima.astype(np.uint8)*(255))
    return ultima

#finding minimum encompassing circle - needs to be binary (1 and 0)
def spei3D(pic):
    ultima = pic + 0
    z,v,h = ultima.shape
    zc, vc, hc, = nd.center_of_mass(ultima)
    o = np.ones((z,v,h))+0
    o[np.int(np.round(zc)), np.int(np.round(vc)),np.int(np.round(hc))] = 0
    dist = nd.distance_transform_edt(o)
    vals = dist*ultima
    r = vals.max()
    r = np.int(np.ceil(r))
    pixels = 8*(r**3)
    w_ei = ultima.sum()
    b_ei = pixels - w_ei
    sp = w_ei/pixels
    return sp, w_ei, b_ei

#originally from page 266 of Kinser (2018)
#gives some shape metrics
#this version only provides eccentricity
#adds third eigenvalue
def Metrics(orig):
    #nonzero locations
    #z= z direction, v = x direction, h = y direction
    z, v, h = orig.nonzero()
    #setup for eigenvale decomposition
    mat = np.zeros((3, len(v)))
    mat[0] = z
    mat[1] = v
    mat[2] = h
    #extracting the eigenvalues and eigenvectors
    evls, evcs = np.linalg.eig(np.cov(mat))
    #sorting the value
    evls = np.sort(evls)[::-1]
    #obtaining eccentricity between the 1st and 2nd axis lengths
    eccen = evls[0]/evls[1]
    if eccen < 1: eccen = 1/eccen
    return eccen, evls[0], evls[1], evls[2]

#calculate shape metrics
def Shapes(pic):
    #setup
    shapes = np.zeros((1,9))
    #obtain sp and eis
    sp, w_ei, b_ei = spei3D(pic)
    #obtain volume
    #vol = pic.sum()
    shapes[0][0] = sp
    shapes[0][1] = w_ei
    shapes[0][2] = b_ei
    #obtain surface area
    sa = pic.sum() - ((nd.binary_erosion(pic , iterations=1))+0.0).sum()
    shapes[0][3] = sa
    #obtain sphericity
    spher = ( (np.pi**(1/3))* ((6*w_ei)**(2/3)) ) / (sa)
    shapes[0][4] = spher
    #provides eccentricity, eigen1, eigen2, and eigen3
    eccen, e1, e2, e3 = Metrics(pic)
    shapes[0][5] = eccen
    shapes[0][6] = e1
    shapes[0][7] = e2
    shapes[0][8] = e3
    return shapes

#calculate intensity metrics
def Intensity(pic, shape):
    #setup
    tents = np.zeros((1,11))
    #obtain nonbackground pixels
    vals = np.where(shape.flatten()>0.0)
    #mean intensity value
    tents[0][0] = pic.flatten()[vals].mean()
    #sd intensity value
    tents[0][1] = pic.flatten()[vals].std()
    #median intensity value
    tents[0][2] = np.quantile(a=pic.flatten()[vals], q=0.5)
    #min intensity value
    tents[0][3] = np.amin(pic.flatten()[vals])
    #25% intensity value
    tents[0][4] = np.quantile(a=pic.flatten()[vals], q=0.25)
    #75% intensity value
    tents[0][5] = np.quantile(a=pic.flatten()[vals],q=0.75)
    #max intensity value
    tents[0][6] = np.amax(pic.flatten()[vals])
    #skewness intensity value
    tents[0][7] = stats.skew(pic.flatten()[vals])
    #mode intensity value
    #tents[0][8] = 0#stats.mode(pic.flatten()[vals])
    #kurtosis intensity value
    tents[0][8] = stats.kurtosis(pic.flatten()[vals])
    #percent of voxels greater than 24000(approximate median of 3rd class pixel intensity)
    tents[0][9] = np.sum(pic.flatten()[vals]>24000)/np.shape(vals)[1]
    #percent of voxels greater than 30000
    tents[0][10] = np.sum(pic.flatten()[vals]>30000)/np.shape(vals)[1]
    return tents


#function to report the cds using intensity and shape information
def report_cds(img, save_img=False, save_dir=None, fname='example.tif', save_elbow=False):
    #finding the nonzero locations
    z, v, h = img.nonzero()
    #reformat the locations
    mat = np.vstack((z,v,h)).T
    #load the original image
    adata = ii.volread(fname)
    #apply mask to original image
    check = adata*img
    #first invert the max and min values
    inverted = check.max() - check
    #now find the max peaks while using the mask
    peaks = peak_local_max(inverted, threshold_rel=0.60, min_distance=1, labels=img)
    #number of CDs to check
    num_check=10
    #within sum of squares object
    wss = np.zeros((num_check-1))
    #for loop to perform kmeans clustering for each of the different values of K
    for k in range(1, num_check):
        n_colors = k
        kmeans = KMeans(n_clusters=n_colors, random_state=0).fit(peaks)
        labels = kmeans.predict(peaks)
        wss[k-1]= within_sum_of_squares(data=peaks, centroids=kmeans.cluster_centers_, labels=labels)
    if save_elbow==True:
        plt.plot()
        plt.title('WSS Elbow Plot')
        plt.xlabel('Clusters')
        plt.ylabel('WSS')
        plt.scatter(range(1, num_check), wss)
        save_dir='example/wss_elbow_'+fname[-0:-3]+'png'
        Path("example").mkdir(parents=True, exist_ok=True)
        plt.savefig(save_dir)
    #finding the elbow in the elbow plot using WSS
    val = KneeLocator(range(1, num_check), wss, curve='convex', direction='decreasing')
    #saving the number of domains
    n_colors = val.knee
    #extracting the clusters
    kmeans = KMeans(n_clusters=n_colors, random_state=0).fit(peaks)
    clusters = img + 0.0
    cds = []
    labels = kmeans.predict(peaks) + 1
    #obtaining each domain as it's own separate image
    for i in range(0, len(labels)):
        clusters[mat[i][0],mat[i][1], mat[i][2]] = labels[i]
    for i in range(1, n_colors+1):
        cds.append( (clusters==i)+0.0 )
    #reformatting the data to output the object with cluster label values
    labels = np.round((labels)*(255/(labels.max()) ))
    for i in range(0, len(labels)):
        clusters[mat[i][0],mat[i][1], mat[i][2]] = labels[i]
    #save image object
    if save_img==True:
        for i in range(0, len(cds)):
            save_dir='example/cds_'+str(i)+'_'+fname
            Path("example").mkdir(parents=True, exist_ok=True)
            ii.volsave(save_dir, cds[i].astype(np.uint8)*255)
    #return clusters, val.knee
    return cds, n_colors


#from http://statweb.stanford.edu/~jtaylo/courses/stats202/kmeans.html
def within_sum_of_squares(data, centroids, labels):
    SSW = 0
    for l in np.unique(labels):
        data_l = data[labels == l]
        resid = data_l - centroids[l]
        SSW += (resid**2).sum()
    return SSW

#end of metric and image opertor functions

#begin mass collection functions

#getting all images with different file types
def GetPicNames( indir ):
    a = os.listdir( indir )
    #remove all files where images begin with a period
    b = [ x for x in a if "._" not in x ]
    pgmnames= []
    for t in b:
        if '.tif' in t:
            pgmnames.append( indir + '/' + t )
    return pgmnames


#obtaining images for shape metrics except EIs
def GetAllCDs( dirs, add_val):
    #object to hold shape metrics
    mgs = []
    #object to hold the intensity metrics
    tents = []
    #object to hold the number of clusters
    clsts = []
    #object to hold the shape of each input image
    sizes = []
    for d in dirs:
        mgnames = GetPicNames( d )
        for j in mgnames:
            #smooth the image
            adata = Smooth(fname=j, save_img=False)
            #get sizes
            sizes.append(adata.shape)
            #threshold to binarize
            bdata = Otsu(adata, save_img=False, fname=j)
            #isolate
            ddata = Isolate2(bdata, save_img=False, fname=j, iterations=1)
            #extend z dimension to proper size
            extend = Construct(img=ddata,fname=j, save_img=False, add=add_val)
            #extracting clusters
            cds, k = report_cds(img=ddata, fname=j)
            for i in range(1, len(cds)):
                #extracting shape metrics
                shape_metrics = Shapes(cds[i])
                shape_metrics = np.append(shape_metrics, k)
                #apply mask on original image
                check = ApplyMask(mask=cds[i],fname=j, save_img=False)
                #extend target
                ultima = Construct(img=check,fname=j, save_img=False, add=add_val)
                #extract intensity metrics
                intensity_metrics = Intensity(ultima)
                #add measurements to lists
                mgs.append( shape_metrics )
                tents.append(intensity_metrics)
    return mgs, tents, sizes


#collect shape metrics from raw data
#outputs 3 txt files
#1: names of each file
#2: the final clusters for each image
#3: the shape metrics for each image
def BinaryCDsTXT(tname, dirs, add_val):
    #obtain shape metrics
    shapes, tents, sizes = GetAllCDs(dirs, add_val)
    #get image names
    name_shape = "CDS_SHAPES_"+tname+'.txt'
    name_tents = "CDS_INTENSITY_"+tname+'.txt'
    name_sizes = "IMAGE_SIZES"+tname+'.txt'
    #get image names
    names = GetPicNames( dirs[0] )
    #save as txt
    np.savetxt("CDS_NAMES_"+tname+'.txt', np.asarray(names), delimiter=',', header="image", comments='', fmt="%s")
    np.savetxt(name_shape, np.vstack(shapes), delimiter=',', header="SP, W_EI, B_EI, Surface_Area, Sphericity, Eccentricity, E1, E2, E3, NumCDs", comments='')
    np.savetxt(name_tents, np.vstack(tents), delimiter=',', header="Mean, SD, Med, Min, Q1, Q3, Max, Skew, Kurt, PercGrt2_4, PercGrt3", comments='')
    np.savetxt(name_sizes, np.vstack(sizes), delimiter=',', header="z, v, h", comments='')
