#r functions to make graphics quicker

#histogram by 2 classes

hist_2<-function(data, classes, var.name){

  #extracting classes
  grps<-as.character(unique(train[,1]))

  #creating vectors with data by group
  A<-(data[which(train[,1]==grps[2])])
  B<-(data[which(train[,1]==grps[1])])

  # Make a neat vector for the breakpoints
  b<-min(c(A, B))-max(c(sd(A), sd(B)))
  e<-max(c(A, B))+max(c(sd(A), sd(B)))
  ax <- pretty(b:e, n = 15)

  #histograms
  hgA <- hist(A, breaks = ax, plot = FALSE) # Save first histogram data
  hgB <- hist(B, breaks = ax, plot = FALSE) # Save 2nd histogram data

  #frequency counts
  frq<-max(c(hgA$counts, hgB$counts))

  #colors
  c1=rgb(0,0,255,max = 255, alpha = 95, names = "lt.blue")
  c2=rgb(0,255,0,max = 255, alpha = 95, names = "lt.green")

  plot(hgA, col = c1, ylim=c(0,frq),
       main=var.name,
       xlab="",
       ylab='',
       xaxt='n',
      cex.main=3,
      cex.lab=1.3)
  plot(hgB, col = c2,
       add = TRUE,
       ylim=c(0,frq),
       xlab="",
       ylab='',
       xaxt='n') # Add 2nd histogram using different color

}


#function to calculate the jaccard index
#source: https://www.r-bloggers.com/2021/11/how-to-calculate-jaccard-similarity-in-r/
jaccard <- function(a, b) {
    tab<-table(a,b)
    #first = tab[1,1]/sum(tab)
    second = tab[2,2]/(sum(tab)-tab[1,1])
    #return (first+second)
    return( second)
}


bal_acc<-function(a, b){

    tab<-table(a, b)
    first<-tab[1,1]/(tab[1,1]+tab[1,2])
    second<-tab[2,2]/(tab[2,2]+tab[2,1])
    return ((first+second)*0.5)
}
